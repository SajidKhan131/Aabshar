/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Language, ActivePage } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { FloatingControls } from './components/FloatingControls';
import { HomeView } from './components/HomeView';
import { ProductsView } from './components/ProductsView';
import { DeliveryView } from './components/DeliveryView';
import { B2BView } from './components/B2BView';
import { QualityView } from './components/QualityView';
import { AboutView } from './components/AboutView';
import { ContactView } from './components/ContactView';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [activePage, setActivePage] = useState<ActivePage>('home');

  const renderActiveView = () => {
    switch (activePage) {
      case 'home':
        return <HomeView language={language} setActivePage={setActivePage} />;
      case 'products':
        return <ProductsView language={language} />;
      case 'delivery':
        return <DeliveryView language={language} />;
      case 'b2b':
        return <B2BView language={language} />;
      case 'quality':
        return <QualityView language={language} />;
      case 'about':
        return <AboutView language={language} />;
      case 'contact':
        return <ContactView language={language} />;
      default:
        return <HomeView language={language} setActivePage={setActivePage} />;
    }
  };

  return (
    <div className={`min-h-screen bg-accent-brand flex flex-col justify-between ${language === 'ur' ? 'select-none' : ''}`}>
      
      {/* Sticky Header Navbar */}
      <Navbar
        language={language}
        setLanguage={setLanguage}
        activePage={activePage}
        setActivePage={setActivePage}
      />

      {/* Primary Transition View Container */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage + '-' + language}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: 'easeInOut' }}
          >
            {renderActiveView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Fast WhatsApp Actions & Back To Top */}
      <FloatingControls language={language} />

      {/* Global Footer Widget */}
      <Footer language={language} setActivePage={setActivePage} />

    </div>
  );
}
