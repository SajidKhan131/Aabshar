/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ActivePage, Language } from '../types';
import { AabsharLogo } from './AabsharLogo';
import { translations } from '../utils/translations';
import { Facebook, Instagram, Phone, Mail, CheckCircle2, Heart } from 'lucide-react';

interface FooterProps {
  language: Language;
  setActivePage: (page: ActivePage) => void;
}

export const Footer: React.FC<FooterProps> = ({ language, setActivePage }) => {
  const t = translations[language];

  const handleLinkClick = (pageId: ActivePage) => {
    setActivePage(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={`bg-[#F3FAFF] text-text-primary pt-16 pb-8 border-t border-primary-brand/10 ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          
          {/* Column 1: Brand details */}
          <div className="flex flex-col gap-4">
            <AabsharLogo className="h-10 text-primary-brand animate-float-slow" showText={true} />
            <p className="text-text-primary/75 text-sm mt-2 leading-relaxed max-w-sm font-medium">
              {t.footerBrandDesc}
            </p>
            <div className="flex items-center gap-4 mt-4">
              <a
                href="https://facebook.com/AabsharWater"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full bg-primary-brand/5 border border-primary-brand/10 flex items-center justify-center hover:bg-primary-brand hover:text-white transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com/AabsharWater"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full bg-primary-brand/5 border border-primary-brand/10 flex items-center justify-center hover:bg-primary-brand hover:text-white transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              {/* Custom TikTok SVG since Lucide doesn't have it natively sometimes */}
              <a
                href="https://tiktok.com/@AabsharWater"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full bg-primary-brand/5 border border-primary-brand/10 flex items-center justify-center hover:bg-primary-brand hover:text-white transition-colors"
              >
                <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2a1 1 0 0 0-1 1v14.003a2.498 2.498 0 1 1-3-2.454V12.5a4.496 4.496 0 1 0 5 4.397V8.55A6.983 6.983 0 0 0 17 11h1a1 1 0 0 0 1-1 4.99 4.99 0 0 1-5-5V3a1 1 0 0 0-1-1z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-primary-brand font-black text-base mb-6 tracking-wide uppercase">
              {t.footerQuickLinks}
            </h3>
            <ul className="flex flex-col gap-3.5">
              {[
                { id: 'home', label: t.navHome },
                { id: 'products', label: t.navProducts },
                { id: 'quality', label: t.navQuality },
                { id: 'b2b', label: t.navB2b },
                { id: 'about', label: t.navAbout },
                { id: 'contact', label: t.navContact },
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => handleLinkClick(link.id as ActivePage)}
                    className="text-text-primary/75 hover:text-primary-brand transition-colors text-sm font-semibold text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Products offering details */}
          <div>
            <h3 className="text-primary-brand font-black text-base mb-6 tracking-wide uppercase">
              {t.footerProducts}
            </h3>
            <ul className="flex flex-col gap-3.5 text-sm text-text-primary/75 font-medium">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand" />
                <span>{t.product500}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand" />
                <span>{t.product15l}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand" />
                <span>{t.footerB2bWater}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand" />
                <span>{t.footerBulkSupply}</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand" />
                <span>{t.hospSector}</span>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Cities */}
          <div className="flex flex-col gap-4">
            <h3 className="text-primary-brand font-black text-base mb-2 tracking-wide uppercase">
              {t.footerContactInfo}
            </h3>
            <div className="flex flex-col gap-3 text-sm text-text-primary/75 font-medium">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary-brand shrink-0" />
                <a href="tel:+923051999897" className="hover:text-primary-brand transition-colors">+92 305 1999897</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary-brand shrink-0" />
                <span>orders@aabshar.com</span>
              </div>
              
              <div className="mt-2.5 pt-3.5 border-t border-primary-brand/10">
                <span className="block text-primary-brand font-black text-xs mb-1.5 uppercase">
                  {t.coverageCities}
                </span>
                <p className="text-xs text-text-primary/60 leading-relaxed font-semibold">
                  {t.citiesList}
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright display */}
        <div className="mt-16 pt-8 border-t border-primary-brand/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-text-primary/50">
          <p className="text-center sm:text-left font-semibold">
            {t.copRight}
          </p>
          <div className="flex items-center gap-1 bg-primary-brand/5 px-3.5 py-1.5 rounded-full border border-primary-brand/10 font-bold text-primary-brand select-none">
            <span>{t.madeWithUrdu}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
