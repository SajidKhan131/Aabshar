/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { ShieldCheck, Award, FileSpreadsheet, ArrowDownToLine, Droplets, CheckCircle, Flame, Star } from 'lucide-react';

interface QualityViewProps {
  language: Language;
}

export const QualityView: React.FC<QualityViewProps> = ({ language }) => {
  const t = translations[language];

  // Mineral statistics data
  const minerals = [
    { name: t.calcium, symbol: "Ca²⁺", range: "24 – 38 mg/L", desc: t.caBenefit },
    { name: t.magnesium, symbol: "Mg²⁺", range: "12 – 18 mg/L", desc: t.mgBenefit },
    { name: t.potassium, symbol: "K⁺", range: "2.4 – 4.0 mg/L", desc: t.kBenefit },
    { name: t.sodium, symbol: "Na⁺", range: "8 – 15 mg/L", desc: t.naBenefit },
    { name: t.bicarbonate, symbol: "HCO₃⁻", range: "75 – 110 mg/L", desc: t.hcoBenefit },
    { name: t.phLevelName, symbol: "pH Range", range: "7.2 – 7.6", desc: t.phBenefit },
  ];

  // Comparison columns values
  const comparisonData = [
    { sourceEn: t.idealLabelText, sourceUr: "آبشار کا آئیڈیل زون", tds: "120 - 160", mineralsEn: "High (Balanced)", mineralsUr: "مثالی متوازن", tasteEn: "Fresh/Sweet", tasteUr: "شیریں اور تازہ", score: "10/10", active: true },
    { sourceEn: "Bore/Tap Municipal", sourceUr: "نلکے یا بورنگ کا پانی", tds: "350 - 600+", mineralsEn: "Excessive (Hard)", mineralsUr: "ضرورت سے زیادہ کھارا", tasteEn: "Salty/Heavy", tasteUr: "بھاری اور نمکین", score: "4/10", active: false },
    { sourceEn: "RO Filtered Distilled", sourceUr: "فلٹر پلانٹ ڈسٹلڈ", tds: "10 - 45", mineralsEn: "None (Stripped)", mineralsUr: "ناپید (بے اثر)", tasteEn: "Flat/Bitter", tasteUr: "کڑوا اور پھیکا", score: "5/10", active: false },
    { sourceEn: "Carbonated Drinks", sourceUr: "سوڈا اور بوتلیں", tds: "400+", mineralsEn: "Harmful Additives", mineralsUr: "مصنوعی کیمیکلز", tasteEn: "Acidic/Sugary", tasteUr: "تیزابی اور میٹھا", score: "1/10", active: false },
  ];

  return (
    <div className={`pt-20 bg-accent-brand ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 5.1 PAGE HERO */}
      <section className="relative py-20 bg-white border-b border-primary-brand/5 text-center overflow-hidden select-none">
        
        {/* Soft glowing vectors */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-secondary-brand/10 rounded-full filter blur-[80px]" />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <span className="bg-primary-brand/5 border border-primary-brand/10 text-primary-brand rounded-full px-3.5 py-1.5 text-xs font-black uppercase tracking-wider">
            {language === 'en' ? "Clinical Laboratory Approvals" : "لیبرٹی سرٹیفیکیشن شیٹ"}
          </span>
          <h1 className="text-3xl sm:text-5xl font-black font-serif text-primary-brand">
            {t.qualityHeroHeading}
          </h1>
          <p className="text-text-primary/70 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
            {t.qualityHeroSub}
          </p>
        </div>
      </section>


      {/* 5.2 TDS INFOGRAPHIC */}
      <section className="py-24 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-12 border border-primary-brand/5 shadow-xl space-y-12">
          
          <div className="text-center space-y-2 select-none">
            <h2 className="text-2xl sm:text-3xl font-black font-serif text-primary-brand">
              {t.idealZoneCallout}
            </h2>
            <p className="text-xs text-text-primary/60 max-w-2xl mx-auto leading-relaxed">
              {t.qualityTdsSubtitle}
            </p>
          </div>

          {/* Centered Quality Scale representing TDS PPM */}
          <div className="space-y-6 pt-6 select-none">
            
            {/* Visual scale bar */}
            <div className="relative h-14 w-full bg-slate-100 rounded-2xl flex overflow-hidden border border-slate-200 shadow-inner">
              
              {/* 0-50 zone (gray) */}
              <div className="h-full bg-slate-300 w-[15%] flex items-center justify-center text-[9px] font-black text-slate-700">
                0-50
              </div>

              {/* 50-100 zone (light blue) */}
              <div className="h-full bg-blue-100 w-[15%] flex items-center justify-center text-[9px] font-black text-blue-700">
                50-100
              </div>

              {/* 120-160 zone (Aabshar ideal zone highlighted in bright aqua) */}
              <div className="h-full bg-gradient-to-r from-cyan-400 to-secondary-brand w-[30%] flex items-center justify-center text-[10px] sm:text-xs font-black text-white px-2 shadow-md relative">
                <span className="animate-pulse">120 - 160 (IDEAL)</span>
                
                {/* Visual arrow pointer */}
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-secondary-brand rotate-45 border-r border-b border-dark-base/5 z-20" />
              </div>

              {/* 200-300 zone (yellow/acceptable) */}
              <div className="h-full bg-amber-100 w-[20%] flex items-center justify-center text-[9px] font-black text-amber-700">
                200-300
              </div>

              {/* 300+ zone (red/hard) */}
              <div className="h-full bg-rose-200 w-[20%] flex items-center justify-center text-[9px] font-black text-rose-800">
                300+
              </div>

            </div>

            {/* Labels under scale bar */}
            <div className="grid grid-cols-5 gap-1 text-[8px] sm:text-[10px] font-black uppercase text-text-primary/50 text-center uppercase tracking-wide">
              <span>{language === 'en' ? "Distilled / Empty" : "کھوکھلا پانی"}</span>
              <span>{language === 'en' ? "Low Minerals" : "کم منرلز"}</span>
              <span className="text-secondary-brand font-black text-[10px] sm:text-xs">{language === 'en' ? "IDEAL - Aabshar" : "آئیڈیل - آبشار"}</span>
              <span>{language === 'en' ? "Hard Tap" : "کھارا پانی"}</span>
              <span>{language === 'en' ? "Kidney Strain" : "مضر صحت کھار"}</span>
            </div>

            {/* Callout information box */}
            <div className="bg-cyan-500/10 border border-secondary-brand/30 p-6 rounded-2xl text-center space-y-2">
              <span className="text-3xl block">🔬</span>
              <h3 className="font-black text-lg text-primary-brand font-serif">
                {t.idealZoneAabshar}
              </h3>
              <p className="text-xs text-text-primary/75 max-w-lg mx-auto leading-relaxed">
                {t.idealZoneSub}
              </p>
            </div>

          </div>

        </div>
      </section>


      {/* 5.3 MINERAL COMPOSITION PANEL */}
      <section className="py-24 bg-white border-t border-primary-brand/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-16">
          
          <div className="space-y-4 max-w-2xl mx-auto">
            <h2 className="text-3xl font-black text-primary-brand font-serif">
              {language === 'en' ? "Mineral Elements Breakdown Details" : "آبشار منرلز الیکٹرولائٹ رپورٹ"}
            </h2>
            <p className="text-sm text-text-primary/60 leading-relaxed max-w-md mx-auto">
              {language === 'en' ? "Precisely titrated to optimize physiological cellular ionic charge balance." : "رپورٹ کے مطابق ہر گلاس میں متوازن الیکٹرولائٹس چارج موجود ہے۔"}
            </p>
          </div>

          {/* 4-column card grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 text-left">
            {minerals.map((m, idx) => (
              <div
                key={idx}
                className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 shadow-sm space-y-4 hover:shadow-md transition-shadow relative overflow-hidden group"
              >
                
                {/* Back layout chemical symbol overlay background */}
                <div className="absolute top-1 right-2 text-7xl font-sans font-black text-primary-brand/5 select-none transition-transform duration-500 group-hover:scale-105">
                  {m.symbol}
                </div>

                <div className="space-y-1">
                  <h3 className="font-black text-lg text-primary-brand">{m.name}</h3>
                  <span className="inline-block bg-primary-brand/10 text-primary-brand text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {m.range}
                  </span>
                </div>

                <p className="text-xs text-text-primary/75 leading-relaxed relative z-10">
                  {m.desc}
                </p>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* 5.4 LAB CERTIFICATION DISPLAY */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-16">
        
        <div className="space-y-3 max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-primary-brand font-serif">
            {t.labNameTitle}
          </h2>
          <p className="text-sm text-text-primary/60">
            {t.labNameSub}
          </p>
        </div>

        {/* 3 cards grid certificate design */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          
          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm space-y-4 relative group">
            <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center text-secondary-brand shrink-0">
              <Award className="h-6 w-6" />
            </div>
            <h3 className="font-bold text-lg text-primary-brand font-serif">PSQCA APPROVED STATUS</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.certifiedDescPsqca}</p>
            <div className="pt-4 border-t border-primary-brand/5">
              <span className="text-[10px] font-black text-cyan-600 block uppercase">Registration No: ML-47822</span>
            </div>
          </div>

          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm space-y-4 relative group">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-primary-brand shrink-0">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <h3 className="font-bold text-lg text-primary-brand font-serif">ISO 9001:2015 STANDARDS</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.certifiedDescIso}</p>
            <div className="pt-4 border-t border-primary-brand/5">
              <span className="text-[10px] font-black text-primary-brand block uppercase">Status: Fully Compliant</span>
            </div>
          </div>

          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm space-y-4 relative group">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 shrink-0">
              <FileSpreadsheet className="h-6 w-6" />
            </div>
            <h3 className="font-bold text-lg text-primary-brand font-serif">CLINICAL DAILY TESTS LOGIN</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.certifiedDescLab}</p>
            <div className="pt-4 border-t border-primary-brand/5">
              <button
                onClick={() => window.open('https://wa.me/923004752668?text=Hello%20Aabshar!%20Could%20you%20please%20send%20me%20the%20latest%20lab%20certification%20and%20mineral%20composition%20PDF%20test%20reports?', '_blank')}
                className="inline-flex items-center gap-1.5 text-xs font-black text-indigo-700 hover:text-indigo-600 group uppercase"
              >
                <ArrowDownToLine className="h-3.5 w-3.5 group-hover:translate-y-0.5 transition-transform" />
                <span>Request Mineral Sheet PDF</span>
              </button>
            </div>
          </div>

        </div>

      </section>


      {/* 5.5 WHY TDS MATTERS (Comparison Table) */}
      <section className="py-24 bg-white border-t border-primary-brand/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Left text column */}
            <div className="lg:col-span-4 space-y-4 text-left flex flex-col items-start justify-center">
              <span className="bg-primary-brand/5 border border-primary-brand/10 text-primary-brand text-xs font-bold px-3 py-1 rounded-full uppercase">
                {language === 'en' ? "Medical Sourcing Insights" : "پانی کا تجزیہ شیٹ"}
              </span>
              <h2 className="text-3xl font-black font-serif text-primary-brand leading-snug">
                {t.whyTdsTableTitle}
              </h2>
              <p className="text-xs sm:text-sm text-text-primary/70 leading-relaxed">
                {language === 'en' ? "Processed carbonated or distilled drinking systems strip minerals, and bore municipal wells strain kidneys. Aabshar maintains natural balance." : "تق موازنہ شیٹ سے خود تسلی کیجئے کہ آپ کے اور آپ کے اہل خانہ کے لئے کون سے پانی کا انتخاب تندرستی کا باعث ہے۔"}
              </p>
            </div>

            {/* Right comparison table (8 cols) */}
            <div className="lg:col-span-8 overflow-x-auto w-full border border-primary-brand/5 rounded-2xl shadow-xl bg-accent-brand">
              <table className="w-full text-xs text-left text-text-primary/90 border-collapse">
                
                <thead className="bg-[#051C2A] text-white text-[10px] font-black uppercase tracking-wider border-b border-primary-brand/10">
                  <tr>
                    <th className="p-4">{t.tableColWaterType}</th>
                    <th className="p-4 text-center">{t.tableColTdsRange}</th>
                    <th className="p-4 text-center">{t.tableColElectrolytes}</th>
                    <th className="p-4 text-center">{t.tableColTasteRating}</th>
                    <th className="p-4 text-center">{t.tableColHealthRating}</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-primary-brand/5">
                  {comparisonData.map((row, idx) => (
                    <tr
                      key={idx}
                      className={`transition-colors ${
                        row.active
                          ? 'bg-secondary-brand/10 font-bold text-primary-brand border-y-2 border-secondary-brand/30'
                          : 'hover:bg-primary-brand/5'
                      }`}
                    >
                      <td className="p-4 flex items-center gap-2">
                        {row.active && <span className="w-1.5 h-1.5 rounded-full bg-secondary-brand shrink-0" />}
                        <span className="font-bold">{language === 'en' ? row.sourceEn : row.sourceUr}</span>
                      </td>
                      <td className="p-4 text-center font-bold font-mono">{row.tds}</td>
                      <td className="p-4 text-center">{language === 'en' ? row.mineralsEn : row.mineralsUr}</td>
                      <td className="p-4 text-center">{language === 'en' ? row.tasteEn : row.tasteUr}</td>
                      <td className="p-4 text-center font-black">{row.score}</td>
                    </tr>
                  ))}
                </tbody>

              </table>
            </div>

          </div>
        </div>
      </section>


      {/* 5.6 QUALITY PROMISE STRIP */}
      <section className="py-16 bg-[#051C2A] text-white select-none border-t border-white/5 relative z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            
            <div className="p-2 space-y-2">
              <span className="text-3xl filter drop-shadow">🏔️</span>
              <p className="text-xs text-white/60 font-medium">{t.mountainOrigin}</p>
              <p className="text-[10px] text-white/40 block leading-relaxed">{language === 'en' ? "Tested directly at mountain source points" : "قدرتی اور برفیلے چشمے کا خالص پانی"}</p>
            </div>

            <div className="p-2 space-y-2">
              <span className="text-3xl filter drop-shadow">🔒</span>
              <p className="text-xs text-white/60 font-medium">{language === 'en' ? "Sealed Integrity" : "ایئر ٹائٹ لوکڈ"}</p>
              <p className="text-[10px] text-white/40 block leading-relaxed">{language === 'en' ? "Double sealed at spring - absolute zero exposure" : "فیکٹری پیکیجنگ میں جگر سیل سسٹم"}</p>
            </div>

            <div className="p-2 space-y-2">
              <span className="text-3xl filter drop-shadow">🌿</span>
              <p className="text-xs text-white/60 font-medium">{t.zeroAdditives}</p>
              <p className="text-[10px] text-white/40 block leading-relaxed">{language === 'en' ? "Absolutely chemical and synthetic free" : "مصنوعی رنگ اور ذائقے سے پاک"}</p>
            </div>

            <div className="p-2 space-y-2">
              <span className="text-3xl filter drop-shadow">💧</span>
              <p className="text-xs text-white/60 font-medium">{language === 'en' ? "Balanced Minerals" : "قدرتی باڈی چارج"}</p>
              <p className="text-[10px] text-white/40 block leading-relaxed">{language === 'en' ? "Preserved natural trace minerals content" : "الیکٹرولائٹس چارج مکمل بحال"}</p>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
