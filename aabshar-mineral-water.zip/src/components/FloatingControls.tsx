/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MessageCircle, ArrowUp } from 'lucide-react';
import { Language } from '../types';

interface FloatingControlsProps {
  language: Language;
}

export const FloatingControls: React.FC<FloatingControlsProps> = ({ language }) => {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > window.innerHeight * 0.5) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappLink = `https://wa.me/923051999897?text=${encodeURIComponent(
    language === 'en'
      ? "Hello Aabshar! I'd like to place an order for premium mineral water. Please quote."
      : "اسلام علیکم آبشار! مجھے پریمیم منرل واٹر پانی کا آرڈر دینا ہے۔ تفصیل بتائیں۔"
  )}`;

  return (
    <div className={`fixed bottom-6 z-50 flex flex-col gap-3 min-w-[56px] ${language === 'ur' ? 'left-6' : 'right-6'}`}>
      
      {/* Back to Top */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="w-12 h-12 bg-primary-brand text-white rounded-full flex items-center justify-center shadow-lg hover:bg-secondary-brand hover:text-dark-base border border-white/10 hover:scale-115 transition-all outline-none"
          title={language === 'en' ? 'Scroll to top' : 'اوپر سکرول کریں'}
        >
          <ArrowUp className="h-5 w-5" />
        </button>
      )}

      {/* Floating WhatsApp Action */}
      <a
        href={whatsappLink}
        target="_blank"
        rel="noreferrer"
        className="group relative w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-xl pulse-glow-whatsapp hover:scale-110 active:scale-95 transition-all select-none"
      >
        <MessageCircle className="h-7 w-7 fill-white text-green-500" />
        
        {/* Tooltip on hover */}
        <span
          className={`absolute whitespace-nowrap bg-dark-base text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-lg border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none ${
            language === 'ur' ? 'left-16 font-urdu' : 'right-16 font-sans'
          }`}
        >
          {language === 'en' ? '📱 Order Now' : 'آرڈر کرنے کے لیے کلک کریں 📱'}
        </span>
      </a>

    </div>
  );
};
