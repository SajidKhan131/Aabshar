/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { HelpCircle, Building, Hotel, Utensils, Award, MessageCircle, Paintbrush, Send, FileCheck } from 'lucide-react';

interface B2BViewProps {
  language: Language;
}

export const B2BView: React.FC<B2BViewProps> = ({ language }) => {
  const t = translations[language];

  // Interactive Label Simulator State
  const [activeBrand, setActiveBrand] = useState<number>(0);
  const brandTemplates = [
    {
      nameEn: "Grand Pearl Luxury Hotel",
      nameUr: "گرینڈ پرل لگژری ہوٹل",
      color: "from-amber-600 to-amber-900",
      accent: "#D4AF37", // Gold
      tagEn: "Complimentary Suite Hydration",
      tagUr: "کمروں کے لیے اعزازی تحفہ",
      bgStyle: "bg-[#1C1610]"
    },
    {
      nameEn: "The Alpine Cafe & Roasters",
      nameUr: "دی الپائن کلاسک کیفے",
      color: "from-green-700 to-[#1F2E24]",
      accent: "#A8E6CF", // Mint
      tagEn: "Fresh Sips For Dining Tables",
      tagUr: "ہر ایک دسترخوان کی رونق",
      bgStyle: "bg-[#142018]"
    },
    {
      nameEn: "TechCorp Pakistan (Boardroom)",
      nameUr: "ٹیک کارپ پاکستان اجلاس",
      color: "from-blue-700 to-[#0A1A2F]",
      accent: "#4DBDE8", // Aqua
      tagEn: "Corporate Client Boardroom",
      tagUr: "صرف بورڈ میٹنگ اور گاہکوں کے لیے",
      bgStyle: "bg-[#091522]"
    },
    {
      nameEn: "Al-Noor Signature Wedding",
      nameUr: "النور سگنیچر ویڈنگ ہال",
      color: "from-rose-600 to-rose-950",
      accent: "#FFD700", // Rose Gold
      tagEn: "Make Every Marriage Drop Famous",
      tagUr: "شادی کی یادگار تقریب کے لیے",
      bgStyle: "bg-[#251014]"
    }
  ];

  // Form states
  const [businessName, setBusinessName] = useState('');
  const [contactName, setContactName] = useState('');
  const [phone, setPhone] = useState('');
  const [businessType, setBusinessType] = useState('Hotel');
  const [city, setCity] = useState('');
  const [qty, setQty] = useState('50');
  const [message, setMessage] = useState('');
  const [isSubmitSuccessful, setIsSubmitSuccessful] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const textStr = language === 'en'
      ? `Aabshar Corporate B2B Inquiry:\n\nBusiness: ${businessName}\nContact: ${contactName}\nPhone: ${phone}\nType: ${businessType}\nCity: ${city}\nEst. Qty: ${qty} cartons\nRequirements: ${message}`
      : `کارپوریٹ پانی انکوائری فارم:\n\nکمپنی: ${businessName}\nرابطہ نام: ${contactName}\nنمبر: ${phone}\nقسم: ${businessType}\nشہر: ${city}\nتعداد: ${qty} ڈبے\nہدایت: ${message}`;
    
    setIsSubmitSuccessful(true);
    setTimeout(() => {
      window.open(`https://wa.me/923004752668?text=${encodeURIComponent(textStr)}`, '_blank');
      setIsSubmitSuccessful(false);
    }, 1800);
  };

  return (
    <div className={`pt-20 bg-accent-brand ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 4.1 PAGE HERO - BRIGHT CRYSTAL THEME */}
      <section className="relative py-24 bg-gradient-to-b from-[#E7F3FC] via-[#F6FBFF] to-accent-brand text-text-primary text-center overflow-hidden select-none border-b border-primary-brand/10">
        
        {/* Subtle geometric overlay backing */}
        <div className="absolute inset-x-0 top-0 h-full bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(61,197,236,0.15),transparent)] pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="bg-primary-brand/10 border border-primary-brand/22 text-primary-brand rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-widest leading-none">
            {language === 'en' ? "Luxury Branding Solutions" : "کارپوریٹ کسٹمائزیشن پرو"}
          </span>
          
          <h1 className="text-3xl sm:text-5xl lg:text-5.5xl font-black font-serif leading-none text-primary-brand drop-shadow-sm">
            {t.b2bHeroTitle}
          </h1>
          
          <p className="text-text-primary/75 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed font-medium">
            {t.b2bHeroSub}
          </p>

          <div className="pt-4 flex justify-center">
            <a
              href="#b2b-form"
              className="bg-primary-brand hover:bg-primary-brand/90 hover:scale-103 text-white font-black px-8 py-3.5 rounded-xl shadow-lg shadow-primary-brand/10 transition-all"
            >
              {t.getFreeQuote}
            </a>
          </div>
        </div>
      </section>


      {/* 4.2 WHAT IS PRIVATE LABEL WATER (Interactive design simulator!) */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Explanation Text columns (Left 5 cols) */}
          <div className="lg:col-span-5 space-y-6 text-left flex flex-col items-start">
            <span className="bg-primary-brand/5 border border-primary-brand/15 text-primary-brand text-xs font-bold px-3 py-1 rounded-full uppercase">
              {language === 'en' ? "Art & Purity" : "ڈیزائننگ سلوشنز"}
            </span>

            <h2 className="text-2xl sm:text-3xl font-black font-serif text-primary-brand">
              {t.whatIsPrivateLabel}
            </h2>

            {/* Explanation steps */}
            <ul className="space-y-4 w-full text-sm text-text-primary/80">
              <li className="flex gap-3.5 items-start">
                <span className="w-6 h-6 rounded-full bg-primary-brand/5 flex items-center justify-center font-bold text-xs text-primary-brand shrink-0">1</span>
                <p className="leading-relaxed">{t.b2bExplainStepEn1}</p>
              </li>
              <li className="flex gap-3.5 items-start">
                <span className="w-6 h-6 rounded-full bg-primary-brand/5 flex items-center justify-center font-bold text-xs text-primary-brand shrink-0">2</span>
                <p className="leading-relaxed">{t.b2bExplainStepEn2}</p>
              </li>
              <li className="flex gap-3.5 items-start">
                <span className="w-6 h-6 rounded-full bg-primary-brand/5 flex items-center justify-center font-bold text-xs text-primary-brand shrink-0">3</span>
                <p className="leading-relaxed">{t.b2bExplainStepEn3}</p>
              </li>
              <li className="flex gap-3.5 items-start">
                <span className="w-6 h-6 rounded-full bg-primary-brand/5 flex items-center justify-center font-bold text-xs text-primary-brand shrink-0">4</span>
                <p className="leading-relaxed">{t.b2bExplainStepEn4}</p>
              </li>
            </ul>
          </div>

          {/* Interactive Bottle Simulator (Right 7 cols) */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-10 border border-primary-brand/5 shadow-xl space-y-6">
            
            <div className="text-center space-y-1 select-none">
              <h3 className="font-bold text-lg text-primary-brand">
                {language === 'en' ? "Interactive Label Preview" : "لیبل کا جادوئی نمونہ آرٹ"}
              </h3>
              <p className="text-[10px] text-text-primary/50 max-w-sm mx-auto leading-relaxed">
                {t.mockupDesignDisclaimer}
              </p>
            </div>

            {/* Switch template buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {brandTemplates.map((template, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveBrand(idx)}
                  className={`p-2 rounded-xl text-center border text-[10px] sm:text-xs font-bold transition-all select-none ${
                    activeBrand === idx
                      ? 'border-primary-brand bg-primary-brand/5 text-primary-brand shadow-sm'
                      : 'border-primary-brand/5 hover:border-primary-brand/20 text-text-primary/60 bg-accent-brand/50'
                  }`}
                >
                  {language === 'en' ? template.nameEn.split(' ')[0] : template.nameUr.split(' ')[0]}
                </button>
              ))}
            </div>

            {/* Simulated bottle with changing CSS styles */}
            <div className={`p-8 rounded-2xl relative h-[320px] flex items-center justify-center transition-all duration-500 overflow-hidden ${brandTemplates[activeBrand].bgStyle}`}>
              
              {/* Bottle vector diagram */}
              <div className="w-32 h-64 bg-cyan-100/50 rounded-3xl border-2 border-cyan-400/40 relative flex items-center justify-center select-none animate-float-medium">
                
                {/* Bottle Cap */}
                <div className="absolute -top-4 w-10 h-4 bg-cyan-500 rounded-t-md border border-cyan-400" />
                <div className="absolute -top-2 w-10 h-2 bg-cyan-600 rounded-t-sm" />

                {/* Simulated customizable label block */}
                <div className={`absolute w-full h-[110px] left-0 transition-all duration-500 bg-gradient-to-r p-3 flex flex-col items-center justify-center text-center shadow-lg border-y border-white/10 ${brandTemplates[activeBrand].color}`}>
                  <div className="w-4 h-4 rounded-full bg-white/15 flex items-center justify-center mb-1 text-[8px] font-black text-white">★</div>
                  
                  <p className="text-[10px] font-black text-white leading-tight uppercase font-serif" style={{ color: brandTemplates[activeBrand].accent }}>
                    {language === 'en' ? brandTemplates[activeBrand].nameEn : brandTemplates[activeBrand].nameUr}
                  </p>
                  
                  <p className="text-[7px] text-white/70 uppercase tracking-wider block leading-tight mt-0.5" style={{ fontSize: '7px' }}>
                    {language === 'en' ? brandTemplates[activeBrand].tagEn : brandTemplates[activeBrand].tagUr}
                  </p>
                  
                  <p className="text-[6px] text-white/40 block uppercase mt-1.5" style={{ fontSize: '6px' }}>
                    Aabshar Source Purity
                  </p>
                </div>

                <div className="absolute bottom-4 text-center text-[7px] font-bold text-cyan-600/40 tracking-widest uppercase">
                  Aabshar 500ml
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>


      {/* 4.3 WHO IS IT FOR? */}
      <section className="py-24 bg-white border-t border-primary-brand/5 text-center space-y-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          <h2 className="text-3xl font-black text-primary-brand font-serif">
            {t.whoIsItForTitle}
          </h2>
          <p className="text-sm text-text-primary/70 leading-relaxed max-w-xl mx-auto">
            {t.whoIsItForSub}
          </p>
        </div>

        {/* 6-card grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
          
          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700">
              <Hotel className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.clientsHotel}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">{t.clientsHotelDesc}</p>
          </div>

          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center text-orange-700">
              <Utensils className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.clientsRestaurant}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">{t.clientsRestaurantDesc}</p>
          </div>

          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-primary-brand">
              <Building className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.clientsCorporate}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">{t.clientsCorporateDesc}</p>
          </div>

          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center text-rose-700">
              <Award className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.clientsEvents}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">{t.clientsEventsDesc}</p>
          </div>

          {[
            // Extra cards from Who is it for
          ]}
          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700">
              <Building className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{language === 'en' ? "Retail Private Labels" : "ریٹیل پرائیویٹ لیبلز"}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">{t.clientsDistributorDesc}</p>
          </div>

          <div className="bg-accent-brand p-6 rounded-2xl border border-primary-brand/5 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center text-green-700">
              <FileCheck className="h-5 w-5" />
            </div>
            <h3 className="font-black text-base text-primary-brand">{language === 'en' ? "Club & Gym branding" : "پریمیم فٹنس جم اینڈ کلبز"}</h3>
            <p className="text-xs text-text-primary/60 leading-relaxed">
              {language === 'en' ? "Reinforce body fitness, hydration, and organic trust inside your fitness studio." : "جم ممبرز اور کھلاڑیوں کی تندرستی کے لئے برانڈ منرل واٹر ڈوبل گرانٹڈ پیکیجنگ فراہم کریں۔"}
            </p>
          </div>

        </div>
      </section>


      {/* 4.4 BRANDED BOTTLE MOCKUP SHOWCASE */}
      <section className="py-24 bg-dark-base text-white text-center space-y-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          <h2 className="text-3xl font-black font-serif text-white">
            {t.mockupShowcaseHeading}
          </h2>
          <p className="text-sm text-white/60">
            {language === 'en' ? "Examples of real premium hotel-grade custom bottles we design to represent your brand." : "اعلی ترین ریستوران میں ہمارے تیار کردہ منرل واٹر ڈسپلے کا ایک خوبصورت منظر۔"}
          </p>
        </div>

        {/* Studio luxury labeled bottle mockup we generated */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center select-none">
          <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/5 bg-[#0A1116] max-w-xl group">
            <img
              src="/src/assets/images/aabshar_b2b_luxury_1779696243785.png"
              alt="Aabshar custom branded luxury design labeled bottle mockup"
              className="w-full h-auto group-hover:scale-103 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-dark-base via-transparent p-6 text-center">
              <p className="text-xs text-secondary-brand font-black uppercase tracking-widest leading-none">
                {language === 'en' ? "Finished Luxury Brand Sample" : "فائنل لگژری مینوفیکچرنگ آرٹ"}
              </p>
            </div>
          </div>
        </div>
      </section>


      {/* 4.5 HOW IT WORKS (B2B Process) */}
      <section className="py-24 bg-white max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-16 border-t border-primary-brand/5">
        <h2 className="text-3xl font-black font-serif text-primary-brand">
          {t.b2bTimelineTitle}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          
          <div className="p-6 bg-accent-brand rounded-2xl border border-primary-brand/5 space-y-3 relative text-left">
            <span className="text-3xl">📞</span>
            <h4 className="font-bold text-base text-primary-brand">{language === 'en' ? "Step 1: Contact Team" : "مرحلہ 1: ٹیم سے رابطہ"}</h4>
            <p className="text-xs text-text-primary/60 leading-relaxed">
              {language === 'en' ? "Submit the inquiry form below, or WhatsApp/call our corporate manager directly." : "نیچے دیئے گئے کارپوریٹ فارم یا فون نمبر کے ذریعے ہم سے رابطہ کیجیے۔"}
            </p>
          </div>

          <div className="p-6 bg-accent-brand rounded-2xl border border-primary-brand/5 space-y-3 relative text-left">
            <span className="text-3xl">🎨</span>
            <h4 className="font-bold text-base text-primary-brand">{language === 'en' ? "Step 2: Submit Logo" : "مرحلہ 2: لوگو شئیر کریں"}</h4>
            <p className="text-xs text-text-primary/60 leading-relaxed">
              {language === 'en' ? "Provide your vector logo file and brand identity colors to our graphic designers." : "اپنے برانڈ کا لوگو یا شادی کا نام مینیجر کو روانہ کیجیے تاکہ ڈیزائن شروع ہو۔"}
            </p>
          </div>

          <div className="p-6 bg-accent-brand rounded-2xl border border-primary-brand/5 space-y-3 relative text-left">
            <span className="text-3xl">✅</span>
            <h4 className="font-bold text-base text-primary-brand">{language === 'en' ? "Step 3: Approve Mockup" : "مرحلہ 3: کسٹمائزڈ لیبل منظوری"}</h4>
            <p className="text-xs text-text-primary/60 leading-relaxed">
              {language === 'en' ? "We render an elegant 3D bottle blueprint modeling for your final physical check." : "ہم آپ کے لوگو کا تھری ڈی ماڈل تیار کر کے فائنل ڈیجیٹل تسلی کروائیں گے۔"}
            </p>
          </div>

          <div className="p-6 bg-accent-brand rounded-2xl border border-primary-brand/5 space-y-3 relative text-left">
            <span className="text-3xl">🚚</span>
            <h4 className="font-bold text-base text-primary-brand">{language === 'en' ? "Step 4: Dispatch" : "مرحلہ 4: فیکٹری مینوفیکچرنگ"}</h4>
            <p className="text-xs text-text-primary/60 leading-relaxed">
              {language === 'en' ? "We print water-resistant vinyl labels and deliver the custom cartons free of cost." : "رنگین ایئر ٹائٹ بوتلیں تیار کر کے تیز ترین فری کارگو ٹرانسپورٹ کی جائے گی۔"}
            </p>
          </div>

        </div>
      </section>


      {/* 4.6 B2B INQUIRY FORM */}
      <section id="b2b-form" className="py-24 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-12 border border-primary-brand/5 shadow-2xl relative">
          
          <div className="text-center space-y-2 mb-10 select-none">
            <div className="inline-flex bg-primary-brand/5 border border-primary-brand/10 p-3 rounded-full text-primary-brand mb-2">
              <Paintbrush className="h-6 w-6" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-serif text-primary-brand">
              {t.b2bInquiryFormTitle}
            </h2>
            <p className="text-xs text-text-primary/50 max-w-sm mx-auto leading-relaxed">
              {language === 'en' ? "Free label design consultation. Design process starts in 24 hours." : "لیبل ڈیزائن سروس بالکل مفت فراہم کی جاتی ہے۔"}
            </p>
          </div>

          <form onSubmit={handleInquirySubmit} className="space-y-6 text-left">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{language === 'en' ? "Company / Wedding Name" : "کمپنی / شادی ہال نام"}</label>
                <input
                  type="text"
                  required
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder={language === 'en' ? "e.g., Grand Hotel, Al-Noor Wedding" : "مثال: گرینڈ ہوٹل، ولیمہ آرٹ ہال"}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{language === 'en' ? "Contact Person Name" : "رابطہ کرنے والے کا نام"}</label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder={language === 'en' ? "e.g., Haris Ahmed" : "مثال: حارث احمد"}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formPhone}</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g., 0305-1999897"
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formBusinessType}</label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand bg-accent-brand/45 text-sm outline-none"
                >
                  <option value="Hotel">{language === 'en' ? "Luxury Hotel" : "ہوٹل اینڈ سویٹ"}</option>
                  <option value="Restaurant">{language === 'en' ? "Fine Dining Restaurant / Cafe" : "ریسٹورنٹ یا کیفے"}</option>
                  <option value="Corporate Office">{language === 'en' ? "Corporate Boardroom" : "کارپوریٹ کمپنی اجلاس"}</option>
                  <option value="Weddings / Events">{language === 'en' ? "Wedding & Party Event" : "شادی ہال یا ایونٹ"}</option>
                  <option value="Other">{language === 'en' ? "Other business" : "دیگر"}</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formCitySelect}</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g., Lahore, Islamabad"
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{language === 'en' ? "Est. Monthly Cartons (Min 50)" : "توقع ماہانہ کارٹن (کم از کم 50)"}</label>
                <input
                  type="number"
                  min="50"
                  required
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{language === 'en' ? "Special Label Instructions" : "لیبل پر کیا لکھوانا ہے؟ (خصوصی تفصیل)"}</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                placeholder={language === 'en' ? "Write logo text, styling, background color or phone details you need printed on label..." : "لوگو کے نیچے شہر کا نام، فون نمبر، فیس بک یا کسٹم سلوگن کی تفصیل جو بوٹل لیبل پر پرنٹ کروانی ہے..."}
                className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand outline-none bg-accent-brand/45 text-sm"
              />
            </div>

            {isSubmitSuccessful ? (
              <div className="p-4 bg-green-500/10 border border-green-500/30 text-green-700 font-bold rounded-xl text-center text-xs sm:text-sm animate-pulse select-none">
                ✓ {t.subSuccessDesc}
              </div>
            ) : (
              <button
                type="submit"
                className="w-full bg-primary-brand hover:bg-primary-brand/90 hover:scale-102 transition-all text-white font-black py-4 rounded-xl shadow-lg shadow-primary-brand/10 cursor-pointer text-center"
              >
                {t.b2bFormSubmitBtn}
              </button>
            )}

          </form>

        </div>
      </section>


      {/* 4.7 B2B TRUST SIGNALS - CRYSTAL DESIGN */}
      <section className="py-16 bg-gradient-to-r from-[#EAF5FC] to-[#E3F9FD] text-text-primary border-t border-primary-brand/10 select-none relative z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center divide-y sm:divide-y-0 sm:divide-x divide-primary-brand/15">
            <div className="p-2">
              <span className="text-3xl filter drop-shadow">⚡</span>
              <p className="font-black text-base text-dark-base mt-2">{t.b2bTrustMinOrder}</p>
            </div>
            <div className="p-2 pt-4 sm:pt-2">
              <span className="text-3xl filter drop-shadow">🎨</span>
              <p className="font-black text-base text-dark-base mt-2">{t.b2bTrustTime}</p>
            </div>
            <div className="p-2 pt-4 sm:pt-2">
              <span className="text-3xl filter drop-shadow">👤</span>
              <p className="font-black text-base text-dark-base mt-2">{t.b2bTrustManager}</p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
