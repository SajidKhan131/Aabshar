/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { HeartPulse, Droplets, ShieldCheck, Sparkles, AlertCircle, Smile, Leaf, ArrowRight } from 'lucide-react';

interface AboutViewProps {
  language: Language;
}

export const AboutView: React.FC<AboutViewProps> = ({ language }) => {
  const t = translations[language];

  // Authentic story narrative text bundle
  const storyNarrative = {
    en: {
      badge: "Real-Life Inspiration",
      title: "Born from Care, Committed to Life",
      subtitle: "Aabshar is a purpose-driven startup born from real-life water quality concerns, committed to delivering pure hydration for healthier living.",
      
      crisisTitle: "The Unseen Struggle in Modern Cities",
      crisisText1: "In rapidly growing urban expanses like Rawalpindi, Islamabad, and beyond, water is the lifeblood of our homes. Yet, it has progressively become a hidden source of daily anxiety. Contaminated city networks and severe hard water flow through domestic pipes, carrying heavy calcium scale and toxic impurities that strip our skin of its organic moisture, leaving our hair brittle and lifeless.",
      crisisText2: "Beneath the surface, families are constantly concerned about the long-term impact on kidney health, metabolism, and weaker immune systems. We watched our elders express caution at every glass, and our children fall ill from ordinary taps. Safe hydration is not a luxurious choice—it is the direct, human foundation for every thriving life.",

      founderTitle: "The Moment of Inspiration",
      founderQuote: "“We saw our children suffering from recurrent throat and stomach illness, and our parents hesitant to open the tap. It was a wake-up call. We did not want to just buy filters; we wanted to craft a mineral spring of absolute trust.”",
      founderStory: "Frustrated by artificial, chemically-processed water that tasted dead or municipal supply lines that felt unsafe, Aabshar's founders made a familial promise. They embarked on an obsessive journey to discover naturally pure underground aquifers, refining them with surgical precision to mimic earth's organic mineral streams. This was never a corporate business choice—it was an direct response of care for our families, our children, and our communities.",

      missionTitle: "The Sincere Purpose Behind Aabshar",
      missionText: "We believe a mineral water bottle is and should always be a vessel of health. By stabilizing natural minerals at their precise, doctor-recommended biological levels and protecting each batch with aseptic zero-touch glass layouts, Aabshar ensures your daily water actively rejuvenates skin quality, sustains digestive balance, and delivers peaceful hydration.",

      promiseTitle: "Our Promise to You",
      promises: [
        {
          icon: HeartPulse,
          title: "Total Well-Being First",
          desc: "Sourced for mineral equilibrium that active bodies need, ensuring gut ease and healthy cellular hydration."
        },
        {
          icon: ShieldCheck,
          title: "Rigorous Safety Standards",
          desc: "Filtered without compromise through sterile microscopic barriers, meeting clinical-grade purity benchmarks."
        },
        {
          icon: Leaf,
          title: "Organic Vitality",
          desc: "A natural crisp taste with no heavy, flat, or harsh chemical trace. Hydration exactly as nature intended it."
        }
      ]
    },
    ur: {
      badge: "ایک مخلصانہ آغاز",
      title: "ہماری کہانی، آپ کی تندرستی",
      subtitle: "آبشار ایک مخلصانہ اور مقصد کے تحت شروع کیا گیا اسٹارٹ اب ہے جو پانی کی خراب کوالٹی کی حقیقی فکر سے پیدا ہوا۔ ہم پُرعزم ہیں کہ آپ کی صحت و تندرستی کے لیے زندگی بخش خالص ترین پانی پیش کریں۔",
      
      crisisTitle: "شہری پانی کا بحران اور ہماری تشویش",
      crisisText1: "ہمارے خوبصورت اور تیز رفتار شہروں میں پانی زندگی کا ستون ہے، مگر افسوس آج یہی پانی اب ایک گہری پریشانی بن چکا ہے۔ منرلز کی خرابی اور کلورین ملا پبلک سپلائی کا پانی نلکوں سے بہتا ہے، جو بچوں کی جلد کی قدرتی ملائمت کو چھینتا ہے اور بالوں کے گرنے اور خشکی کا باعث بنتا ہے۔",
      crisisText2: "سب سے تکلیف دہ بات یہ ہے کہ ہارڈ واٹر ہمارے پیاروں کے گردوں اور ہاضمے کی صحت پر گہرے منفی اثرات ڈالتا ہے۔ ہماری مائیں اور بڑے ہر گلاس پیتے وقت شکوک و شبہات کا شکار ہوتے ہیں۔ صاف اور متوازن پانی کوئی عیاشی نہیں—یہ ہر جاندار کا بنیادی حق ہے۔",

      founderTitle: "محرک اور ہماری سوچ",
      founderQuote: "“جب ہم نے اپنے معصوم بچوں کو مسلسل گندے پانی سے بیمار ہوتے اور بزرگوں کو پانی پیتے ہوئے کتراتے دیکھا، تو وہ ہمارے لیے ایک لمحہ فکر تھا۔ ہم نے تہیہ کیا کہ ہم صرف فلٹر نہیں فروخت کریں گے، بلکہ ایک ایسا خالص جھرنا بنائیں گے جس پر آنکھیں بند کر کے بھروسہ کیا جا سکے۔”",
      founderStory: "کیمیکلز سے بھرپور اور مصنوعی طریقے سے تیار کردہ بے جان پانی سے مطمئن نہ ہو کر، آبشار کے بانیان نے ایک مخلصانہ وعدہ کیا۔ انہوں نے زمینی گہرائی سے قدرتی چشموں جیسے صاف ذخائر تلاش کیے اور بہترین ڈبل فلٹریشن ٹیکنالوجی سے اس کے حقیقی ذائقے کو محفوظ کیا۔ آبشار کوئی روایتی کاروبار نہیں، بلکہ ہر فیملی کی صحت کا امین ہے۔",

      missionTitle: "آبشار کا مقصدِ تندرستی",
      missionText: "پانی کی ہر بوتل آپ کی فیملی کی صحت کی ضامن ہونی چاہیے۔ معالجین کی تجویز کردہ متوازن معدنیات کے ذرات کو برقرار رکھتے ہوئے، آبشار معدے کے سکون، جلد کی رونق اور صحت مند زندگی کا تحفہ آپ کی دہلیز تک بحفاظت پہنچانے کے لیے مسلسل کوشاں ہے۔",

      promiseTitle: "آپ سے ہمارا پکا عہد",
      promises: [
        {
          icon: HeartPulse,
          title: "صحت سب سے پہلے",
          desc: "جسم کو مطلوبہ معدنیاتی توازن کی فراہمی جو روزمرہ توانائی اور گردوں کے تحفظ کے لیے بے حد ضروری ہے۔"
        },
        {
          icon: ShieldCheck,
          title: "بے مثال جرثومہ کش فلٹریشن",
          desc: "پاکیزگی کے اعلیٰ ترین عالمی معیار کے مطابق، جہاں انسان کا ہاتھ چھوئے بغیر بوتل تیار اور پیک ہوتی ہے۔"
        },
        {
          icon: Leaf,
          title: "قدرتی فرحت بخش ذائقہ",
          desc: "بغیر کسی بھاری پن یا کیمیاوی ذائقے کے، بالکل ویسا ہی جیسا پہاڑی گلیشیئر کے سینے سے نکلنے والا مصفا جھرنا ہوتا ہے۔"
        }
      ]
    }
  };

  const story = language === 'en' ? storyNarrative.en : storyNarrative.ur;

  // Visual container animation presets
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.18, delayChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: 'spring', stiffness: 50, damping: 18 }
    }
  };

  return (
    <div className={`pt-20 bg-gradient-to-b from-[#F3F9FD] via-[#FFFFFF] to-[#F1F8FD] text-slate-800 ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 1. BRAND STORY HERO SECTION */}
      <section className="relative py-28 sm:py-36 text-center overflow-hidden border-b border-sky-100">
        
        {/* Soft immersive vector layout of glaciers under the hero */}
        <div className="absolute inset-0 z-0 pointer-events-none select-none">
          <img
            src="/src/assets/images/karakoram_glacier_peaks_1779696205621.png"
            alt="Swat Karakoram Glacier natural source background"
            className="w-full h-full object-cover opacity-15 filter blur-xs"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-[#F3F9FD]/40" />
        </div>

        {/* Healing background blur spots */}
        <div className="absolute top-[20%] left-[10%] w-[350px] h-[350px] rounded-full bg-sky-200/20 filter blur-3xl animate-pulse pointer-events-none" />
        <div className="absolute bottom-[10%] right-[15%] w-[450px] h-[450px] rounded-full bg-cyan-100/30 filter blur-3xl pointer-events-none" style={{ animationDuration: '6s' }} />

        <div className="relative z-10 max-w-4xl mx-auto px-6 sm:px-8 lg:px-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <span className="inline-flex items-center gap-1.5 bg-primary-brand/10 border border-primary-brand/20 text-primary-brand px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest leading-none select-none">
              <Sparkles className="h-4 w-4 text-secondary-brand animate-pulse" />
              {story.badge}
            </span>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-serif text-primary-brand tracking-tight leading-tight">
              {story.title}
            </h1>

            <div className="w-16 h-1 bg-gradient-to-r from-primary-brand to-secondary-brand mx-auto rounded-full" />

            <p className="text-lg sm:text-2xl font-light text-slate-600/90 max-w-3xl mx-auto leading-relaxed italic border-l-4 sm:border-l-0 border-secondary-brand/40 pl-4 sm:pl-0">
              {story.subtitle}
            </p>
          </motion.div>
        </div>
      </section>


      {/* 2. THE CHRONICLE OF PURE CARE (THE HARD WATER CRISIS & INSPIRATION) */}
      <section className="py-24 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            
            {/* Visual Box on Left: Custom Branded Luxury Bottle showcase */}
            <motion.div className="lg:col-span-5 space-y-6" variants={itemVariants}>
              <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-[#091116] border border-white/10 group select-none">
                
                {/* Studio premium artesian glass bottle mockup */}
                <img
                  src="/src/assets/images/aabshar_b2b_luxury_1779696243785.png"
                  alt="Aabshar custom branded luxury artesian water bottle glass showcase"
                  className="w-full h-auto object-cover group-hover:scale-103 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />

                {/* Fluid gradient shadow overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#091116] via-[#091116]/25 to-transparent opacity-75 pointer-events-none" />

                {/* Sleek bottom card labeling aligned with the luxury identity */}
                <div className="absolute bottom-0 inset-x-0 p-6 text-center z-10 bg-gradient-to-t from-[#091116] via-[#091116]/90 to-transparent">
                  <p className="text-[10px] font-bold text-sky-400 uppercase tracking-widest">
                    {language === 'en' ? "Aabshar Reserve Edition" : "آبشار گلاسReserve ایڈیشن"}
                  </p>
                  <h4 className="text-white text-base font-black font-serif mt-1">
                    {language === 'en' ? "Custom Branded Artesian Water" : "پہاڑی چشمے کا مصفا پانی"}
                  </h4>
                </div>
              </div>

              {/* Ambient Quote Accent */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-sky-50 to-white border-l-4 border-primary-brand text-xs text-slate-500">
                {language === 'en' 
                  ? "Every bottle we source is an echo of care to safe-keep Pakistan's standard of cellular vitality."
                  : "ہمارا ہر گھونٹ پاکستان کے خاندانوں میں صحت اور قوتِ مدافعت بحال کرنے کا عزم ہے۔"}
              </div>

            </motion.div>


            {/* Informative Story Copy on Right */}
            <motion.div className="lg:col-span-7 space-y-6 text-left" variants={itemVariants}>
              <div className="space-y-2">
                <span className="text-xs font-extrabold text-secondary-brand uppercase tracking-wider block">
                  {language === 'en' ? "The Urban Hydration Challenge" : "انسان دوستی اور احساس"}
                </span>
                <h2 className="text-3xl sm:text-4xl font-black font-serif text-primary-brand tracking-tight leading-tight">
                  {story.crisisTitle}
                </h2>
              </div>

              <div className="text-slate-600 space-y-4 text-sm sm:text-base leading-relaxed font-normal">
                <p>{story.crisisText1}</p>
                <p>{story.crisisText2}</p>
              </div>

              <div className="pt-4 flex flex-wrap gap-4 items-center">
                <div className="flex items-center gap-2 text-primary-brand bg-white border border-sky-100 px-4 py-2 rounded-xl shadow-xs text-xs font-bold">
                  <Droplets className="h-4 w-4 text-sky-500" />
                  <span>{language === 'en' ? "Pristine Deep Sourced" : "قدرتی گہرائی سے مصفا"}</span>
                </div>
                <div className="flex items-center gap-2 text-primary-brand bg-white border border-sky-100 px-4 py-2 rounded-xl shadow-xs text-xs font-bold">
                  <HeartPulse className="h-4 w-4 text-rose-500" />
                  <span>{language === 'en' ? "Biologically Balanced" : "طبی معیار کے عین مطابق"}</span>
                </div>
              </div>
            </motion.div>

          </motion.div>
        </div>
      </section>


      {/* 3. THE FOUNDING MOMENT & EMOTIONAL PROMISE */}
      <section className="py-24 sm:py-32 bg-[#F6FBFF] relative overflow-hidden">
        
        {/* Soft floating mist graphics */}
        <div className="absolute top-[10%] right-[5%] w-72 h-72 rounded-full bg-cyan-150 filter blur-[90px] opacity-40 pointer-events-none" />
        <div className="absolute -bottom-10 left-[5%] w-96 h-96 rounded-full bg-sky-150 filter blur-[100px] opacity-45 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            
            {/* Story Copy on Left */}
            <motion.div className="lg:col-span-7 space-y-6 text-left order-2 lg:order-1" variants={itemVariants}>
              <div className="space-y-2">
                <span className="text-xs font-extrabold text-secondary-brand uppercase tracking-wider block">
                  {language === 'en' ? "The Spark of Hope" : "آبشار کا آغاز"}
                </span>
                <h2 className="text-3xl sm:text-4xl font-black font-serif text-primary-brand tracking-tight leading-tight">
                  {story.founderTitle}
                </h2>
              </div>

              <blockquote className="border-l-4 border-sky-400 pl-6 py-2 text-lg font-medium text-primary-brand italic tracking-normal leading-relaxed">
                {story.founderQuote}
              </blockquote>

              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                {story.founderStory}
              </p>
            </motion.div>


            {/* Dynamic Glassmorphic Core Stat Panel on Right */}
            <motion.div className="lg:col-span-5 order-1 lg:order-2" variants={itemVariants}>
              <div className="relative rounded-3xl overflow-hidden shadow-xl bg-white/70 border border-white p-8 block backdrop-blur-md select-none">
                
                {/* Floating graphic overlay */}
                <div className="absolute top-0 left-0 w-24 h-24 bg-primary-brand/5 rounded-full filter blur-xl pointer-events-none" />
                <div className="absolute bottom-0 right-0 w-32 h-32 bg-secondary-brand/10 rounded-full filter blur-2xl pointer-events-none" />

                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 rounded-full bg-[#E7F3FC] flex items-center justify-center text-primary-brand text-2xl">
                    🌸
                  </div>
                  <div>
                    <h4 className="font-extrabold text-[#0D3859] text-base leading-snug">
                      {language === 'en' ? "Real-Life Commitment" : "خالص منرلز، پکا بھروسہ"}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      {language === 'en' ? "Founder's Promise to Families" : "ہر خاندان کے لیے پیار اور فکر"}
                    </p>
                  </div>
                </div>

                <div className="space-y-6 relative z-10">
                  <div className="p-4 bg-white/80 rounded-2xl border border-sky-100 shadow-sm flex items-start gap-4">
                    <span className="text-xl mt-0.5">🏡</span>
                    <div>
                      <h5 className="font-bold text-slate-800 text-sm">
                        {language === 'en' ? "Zero Corporate Process" : "کیمیکلز سے مکمل پاکیزگی"}
                      </h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {language === 'en' 
                          ? "We maintain natural trace balances unchanged from organic aquifers rather than synthetically introducing dry salts."
                          : "مصنوعی کیمیکلز کے بجائے ہم مٹی کی تہوں سے حاصل ہونے والے حقیقی منرلز کو جوں کا توں برقرار رکھتے ہیں۔"}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-white/80 rounded-2xl border border-sky-100 shadow-sm flex items-start gap-4">
                    <span className="text-xl mt-0.5">👶</span>
                    <div>
                      <h5 className="font-bold text-slate-800 text-sm">
                        {language === 'en' ? "Trusted for All Ages" : "پیدائش سے ضعیف العمری تک"}
                      </h5>
                      <p className="text-xs text-slate-500 mt-1">
                        {language === 'en' 
                          ? "So soft and biologically pure that it can be instantly digested by toddlers to older patients requiring light sodium limits."
                          : "اتنا ہلکا اور ہموار ذائقہ جو معصوم بچوں سے لے کر معمور بزرگوں تک سب کے لیے پینے میں انتہائی صحت بخش ہے۔"}
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>

          </motion.div>
        </div>
      </section>


      {/* 4. THE MISSION MATRIX - PURE SAFE REFRESHING HYDROPOWER */}
      <section className="py-24 sm:py-32 relative bg-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 text-center space-y-16">
          
          <div className="max-w-3xl mx-auto space-y-4">
            <span className="text-xs font-black text-secondary-brand uppercase tracking-widest block">
              {language === 'en' ? "Our Living Goal" : "ہمارا مخلصانہ نشان"}
            </span>
            <h2 className="text-3xl sm:text-4xl font-black font-serif text-primary-brand tracking-tight leading-tight">
              {story.missionTitle}
            </h2>
            <div className="w-12 h-1 bg-sky-200 mx-auto rounded-full mt-3" />
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
              {story.missionText}
            </p>
          </div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            {story.promises.map((p, idx) => {
              const IconComponent = p.icon;
              return (
                <motion.div 
                  key={idx} 
                  className="bg-sky-50/40 p-8 rounded-3xl border border-sky-100 hover:bg-sky-50/70 hover:shadow-lg hover:shadow-sky-100/30 transition-all block group"
                  variants={itemVariants}
                >
                  <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-primary-brand shadow-sm border border-sky-100 mb-6 group-hover:scale-105 transition-transform">
                    <IconComponent className="h-6 w-6 text-sky-600" />
                  </div>
                  <h3 className="text-lg font-extrabold text-[#0D3859] font-serif mb-2">
                    {p.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-medium">
                    {p.desc}
                  </p>
                </motion.div>
              );
            })}
          </motion.div>

        </div>
      </section>


      {/* 5. BRAND STATEMENT STRIP */}
      <section className="bg-gradient-to-r from-sky-50 via-white to-sky-50 text-slate-800 py-20 border-y border-sky-100 relative overflow-hidden select-none">
        
        {/* Aesthetic background details */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-sky-100 filter blur-3xl opacity-50 pointer-events-none" />

        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center space-y-6">
          <Smile className="h-10 w-10 text-secondary-brand mx-auto animate-bounce" style={{ animationDuration: '3s' }} />
          <h3 className="text-xl sm:text-2xl font-black font-serif text-primary-brand tracking-normal italic max-w-2xl mx-auto">
            {language === 'en' 
              ? "“Aabshar is a purpose-driven startup born from real-life water quality concerns, committed to delivering pure hydration for healthier living.”"
              : "“آبشار ایک مخلصانہ اور مقصد کے تحت شروع کیا گیا اسٹارٹ اپ ہے جو پانی کی خراب کوالٹی کی حقیقی فکر سے پیدا ہوا۔ ہم پُرعزم ہیں کہ آپ کی صحت و تندرستی کے لیے زندگی بخش خالص ترین پانی پیش کریں۔”"
            }
          </h3>
          <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold text-slate-400 tracking-widest uppercase">
            <span>AABSHAR MINERAL WATER</span>
            <span>•</span>
            <span>Est. Rawalpindi</span>
          </div>
        </div>
      </section>

    </div>
  );
};
