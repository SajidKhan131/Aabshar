/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { ActivePage, Language } from '../types';
import { translations } from '../utils/translations';
import { WaterfallBackground } from './WaterfallBackground';
import { 
  ShoppingCart, 
  ArrowRight, 
  Sparkles, 
  Truck, 
  Star, 
  MessageSquare, 
  Heart, 
  ShieldCheck, 
  Droplets,
  Award,
  Waves,
  Volume2,
  VolumeX,
  Radio
} from 'lucide-react';

interface HomeViewProps {
  language: Language;
  setActivePage: (page: ActivePage) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ language, setActivePage }) => {
  const t = translations[language];

  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio("https://www.soundjay.com/nature/sounds/river-1.mp3");
    audio.loop = true;
    audio.volume = 0.20; // 20% comfort volume
    audioRef.current = audio;

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const toggleSound = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(err => {
        console.warn("Audio play gesture required:", err);
      });
      setIsPlaying(true);
    }
  };

  const instagramImages = [
    { src: 'https://images.unsplash.com/photo-1555529669-e69e7aa0db9a?auto=format&fit=crop&q=80&w=400', alt: 'Pure Mineral Balance' },
    { src: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?auto=format&fit=crop&q=80&w=400', alt: 'Clinical Hydration Standard' },
    { src: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=400', alt: 'Aabshar Premium Sourced' },
    { src: 'https://images.unsplash.com/photo-1624462966581-bc6d768cbce5?auto=format&fit=crop&q=80&w=400', alt: 'Modern Office Wellness' },
    { src: 'https://images.unsplash.com/photo-1471874276752-65e2d717604a?auto=format&fit=crop&q=80&w=400', alt: 'Pure Hydration Flow' },
    { src: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?auto=format&fit=crop&q=80&w=400', alt: 'Active Healthy Lifestyle' }
  ];

  const handleOrderRedirect = (productName: string) => {
    const text = language === 'en'
      ? `Hello Aabshar! I would like to order Aabshar ${productName} cartons. Please guide me about payment and delivery.`
      : `سلام علیکم آبشار! مجھے آبشار ${productName} کے کارٹن آرڈر کرنے ہیں۔ براہ کرم ڈیلیوری کی معلومات مہیا کریں۔`;
    window.open(`https://wa.me/923051999897?text=${encodeURIComponent(text)}`, '_blank');
  };

  // Animation Variants for staggering entry
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15, delayChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } 
    }
  };

  return (
    <div id="homepage-container" className={`overflow-x-hidden pt-20 bg-[#F4FAFE] ${language === 'ur' ? 'rtl font-urdu' : 'font-sans text-slate-800'}`}>
      
      {/* 1.1 LUXURY HERO SECTION */}
      <section id="hero-section" className="relative min-h-[95vh] flex items-center overflow-hidden bg-gradient-to-b from-[#E7F3FC] via-[#F6FBFF] to-[#F4FAFE] py-16 sm:py-24">
        
        {/* Realistic, Calming and Immersive Aabshar Waterfall Background */}
        <WaterfallBackground />

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 w-full">
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            
            {/* Left Column (Hero copy & CTAs) */}
            <div className="lg:col-span-7 flex flex-col items-start text-left space-y-8">
              
              {/* Badges and Interactive Audio Row */}
              <div className="flex flex-col sm:flex-row flex-wrap gap-3 items-start sm:items-center w-full select-none z-25">
                
                {/* Mountain Source Origin Badge */}
                <motion.div 
                  id="hero-badge"
                  variants={itemVariants}
                  className="inline-flex items-center gap-2 bg-white/70 hover:bg-white/90 border border-primary-brand/15 text-primary-brand px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm backdrop-blur-md select-none transition-all"
                >
                  <Sparkles className="h-4 w-4 text-secondary-brand animate-spin" style={{ animationDuration: '10s' }} />
                  <span>{t.mountainSource}</span>
                </motion.div>

                {/* Immersive Waterfall Sound Toggle Pill */}
                <motion.button
                  id="audio-soundscape-toggle"
                  variants={itemVariants}
                  onClick={toggleSound}
                  className={`inline-flex items-center gap-2.5 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm backdrop-blur-md select-none transition-all relative outline-none focus:ring-2 focus:ring-primary-brand/50 border ${
                    isPlaying 
                      ? 'bg-sky-50/80 hover:bg-sky-50 border-sky-300 text-sky-700 font-extrabold shadow-sky-100/30' 
                      : 'bg-white/50 hover:bg-white/75 border-slate-200 text-slate-600'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {/* Subtle breathing ripple around the button when sound is playing */}
                  {isPlaying && (
                    <span className="absolute inset-0 rounded-full bg-sky-450/10 animate-ping pointer-events-none scale-110" style={{ animationDuration: '2.5s' }} />
                  )}

                  {/* Sound Icons depending on state */}
                  <div className="relative flex items-center justify-center">
                    {isPlaying ? (
                      <Volume2 className="h-4 w-4 text-sky-500 animate-pulse" />
                    ) : (
                      <VolumeX className="h-4 w-4 text-slate-400" />
                    )}
                  </div>

                  <span>{isPlaying ? t.waterfallAudioMute : t.waterfallAudioPlay}</span>

                  {/* Sound Wave Equalizer animation when playing */}
                  <div className="flex items-end gap-0.5 h-3 ml-1 select-none pointer-events-none">
                    <motion.span 
                      className={`w-0.75 rounded-full ${isPlaying ? 'bg-sky-400' : 'bg-slate-300'}`}
                      animate={isPlaying ? { height: [3, 11, 3] } : { height: 3 }}
                      transition={{ repeat: Infinity, duration: 0.5, ease: "easeInOut" }}
                    />
                    <motion.span 
                      className={`w-0.75 rounded-full ${isPlaying ? 'bg-sky-500' : 'bg-slate-300'}`}
                      animate={isPlaying ? { height: [3, 15, 3] } : { height: 3 }}
                      transition={{ repeat: Infinity, duration: 0.7, ease: "easeInOut", delay: 0.1 }}
                    />
                    <motion.span 
                      className={`w-0.75 rounded-full ${isPlaying ? 'bg-sky-400' : 'bg-slate-300'}`}
                      animate={isPlaying ? { height: [3, 8, 3] } : { height: 3 }}
                      transition={{ repeat: Infinity, duration: 0.6, ease: "easeInOut", delay: 0.2 }}
                    />
                  </div>
                </motion.button>

              </div>

              {/* Refined Luxury Typography */}
              <motion.div id="hero-headline-container" variants={itemVariants} className="space-y-4">
                <span className="text-sm font-black tracking-widest uppercase text-secondary-brand block">
                  {t.brandTagline}
                </span>
                <h1 className="text-4xl sm:text-5xl lg:text-7.5xl font-extrabold text-[#0D263F] leading-[1.08] font-serif tracking-tight">
                  <span className="block text-primary-brand">{t.heroHeadline1}</span>
                  <span className="block">{t.heroHeadline2}</span>
                  <span className="block text-[#1CB2FF]">{t.heroHeadline3}</span>
                </h1>
              </motion.div>

              {/* Subheading focusing on elegant clean structure */}
              <motion.p 
                id="hero-description"
                variants={itemVariants}
                className="text-slate-600/90 text-base sm:text-lg max-w-xl leading-relaxed font-normal"
              >
                {t.heroSubheadline}
              </motion.p>

              {/* Micro specs - minimal visual layout */}
              <motion.div 
                id="hero-specs-row"
                variants={itemVariants}
                className="grid grid-cols-3 gap-6 w-full max-w-lg pt-2 border-t border-slate-200/50"
              >
                <div className="flex flex-col">
                  <span className="text-xl font-bold font-serif text-[#0D263F]">135 ppm</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t.tdsBadge}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold font-serif text-[#0D263F]">100%</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t.certifiedBadge}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold font-serif text-[#0D263F]">0/-</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{t.deliveryBadge}</span>
                </div>
              </motion.div>

              {/* Exciting, high-end CTA buttons */}
              <motion.div 
                id="hero-ctas"
                variants={itemVariants}
                className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto pt-4"
              >
                <button
                  onClick={() => setActivePage('contact')}
                  className="w-full sm:w-auto flex items-center justify-center gap-2.5 bg-primary-brand hover:bg-[#0B5FA3] hover:shadow-xl hover:shadow-primary-brand/20 active:scale-98 text-white font-extrabold px-10 py-5 rounded-2xl shadow-lg transition-all select-none group relative overflow-hidden"
                >
                  <ShoppingCart className="h-5 w-5 fill-current text-white/80" />
                  <span>{t.orderNow}</span>
                </button>

                <button
                  onClick={() => setActivePage('products')}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 bg-white/70 hover:bg-white border border-slate-200 hover:border-primary-brand/30 hover:shadow-md text-[#0D263F] font-bold px-10 py-5 rounded-2xl backdrop-blur-sm transition-all select-none"
                >
                  <span>{t.exploreProducts}</span>
                  <ArrowRight className="h-4.5 w-4.5" />
                </button>
              </motion.div>

            </div>

            {/* Right Column - Clean studio family mockup with soft depth */}
            <div className="lg:col-span-5 flex justify-center relative select-none w-full px-4 lg:px-0 mt-8 lg:mt-0">
              
              {/* Backside circular ambient reflections & blur scaled to match */}
              <div className="absolute w-72 h-72 md:w-[440px] md:h-[440px] rounded-full bg-[#1CB2FF]/15 filter blur-[70px] animate-pulse -z-10" />
              
              {/* Elegant floating pedestal container increased in size by ~21% */}
              <motion.div 
                id="hero-mockup-wrapper"
                variants={itemVariants}
                className="relative rounded-3xl p-6 sm:p-7 border border-white bg-white/40 shadow-2xl backdrop-blur-md w-full max-w-[300px] sm:max-w-sm md:max-w-[465px]"
              >
                <img
                  src="/src/assets/images/aabshar_bottles_duo_1779701740908.png"
                  alt="Aabshar Premium Sourced Water Family Bottles"
                  className="rounded-2xl shadow-xl border border-primary-brand/5 relative z-10 w-full h-auto object-contain hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />

                {/* Floating micro glass visual label */}
                <div className="absolute -bottom-4 right-1/2 translate-x-1/2 bg-white/90 text-[#0D263F] rounded-2xl text-[10px] sm:text-xs font-black px-5 py-3 shadow-xl backdrop-blur-md border border-slate-100 z-20 flex items-center gap-2.5 whitespace-nowrap">
                  <span className="text-secondary-brand animate-bounce">💧</span>
                  <span>100% Pure Sourced Glacier Water</span>
                </div>
              </motion.div>

            </div>

          </motion.div>
        </div>

        {/* Waves Dividers */}
        <div className="absolute bottom-0 left-0 right-0 w-full overflow-hidden leading-[0] z-20">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="relative block w-full h-12 text-[#F4FAFE]" fill="currentColor">
            <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86C258,56.44,213,44,168,44,123,44,78,44,32,44V120H985.66Z" opacity=".5"></path>
            <path d="M321.39,56.44c158-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83V120H0V0C26.9,8.75,57.05,18.33,88.75,25.43,158.53,41,213,44,258,44,281.07,44,302.26,41.4,321.39,56.44Z"></path>
          </svg>
        </div>

      </section>


      {/* 1.2 LUXURIOUS TRUST BAR / SOCIAL PROOF STRIP */}
      <section id="trust-bar" className="bg-white py-12 border-y border-slate-100 relative z-10">
        <div className="max-w-7xl mx-auto px-6 sm:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center divide-y sm:divide-y-0 lg:divide-x divide-slate-100/70">
            
            <motion.div 
              whileHover={{ y: -4 }}
              className="flex flex-col items-center justify-center p-3 text-[#0D263F]"
            >
              <div className="w-12 h-12 rounded-xl bg-[#E7F3FC] flex items-center justify-center text-primary-brand text-2xl mb-3 shadow-inner">🏔️</div>
              <p className="text-base font-extrabold">{t.trustNatural}</p>
              <p className="text-xs text-slate-400 font-medium mt-1">{t.trustNaturalSub}</p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -4 }}
              className="flex flex-col items-center justify-center p-3 pt-6 sm:pt-3 text-[#0D263F]"
            >
              <div className="w-12 h-12 rounded-xl bg-[#E3F9FD] flex items-center justify-center text-[#1CB2FF] text-2xl mb-3 shadow-inner">🧪</div>
              <p className="text-base font-extrabold">{t.trustTds}</p>
              <p className="text-xs text-slate-400 font-medium mt-1">{t.trustTdsSub}</p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -4 }}
              className="flex flex-col items-center justify-center p-3 pt-6 sm:pt-3 text-[#0D263F]"
            >
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center text-green-600 text-2xl mb-3 shadow-inner">🚚</div>
              <p className="text-base font-extrabold">{t.trustDelivery}</p>
              <p className="text-xs text-slate-400 font-medium mt-1">{t.trustDeliverySub}</p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -4 }}
              className="flex flex-col items-center justify-center p-3 pt-6 sm:pt-3 text-[#0D263F]"
            >
              <div className="w-12 h-12 rounded-xl bg-yellow-50 flex items-center justify-center text-yellow-600 text-2xl mb-3 shadow-inner">⭐</div>
              <p className="text-base font-extrabold">{t.trustRating}</p>
              <p className="text-xs text-slate-400 font-medium mt-1">{t.trustRatingSub}</p>
            </motion.div>

          </div>
        </div>
      </section>


      {/* 1.3 MODERN CARD-BASED PRODUCTS TEASER */}
      <section id="products-teaser-section" className="py-24 sm:py-32 bg-gradient-to-b from-[#F4FAFE] to-white relative">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 text-center space-y-16">
          
          <div className="space-y-4 max-w-2xl mx-auto">
            <span className="text-primary-brand text-xs font-black uppercase tracking-widest">{t.exploreProducts}</span>
            <h2 className="text-3xl sm:text-4.5xl font-extrabold text-[#0D263F] font-serif">
              {t.choosePerfectSize}
            </h2>
            <div className="w-14 h-1 bg-gradient-to-r from-primary-brand to-secondary-brand mx-auto rounded-full" />
            <p className="text-slate-500 text-sm sm:text-base leading-relaxed pt-2">
              {t.premiumMineralWaterSizes}
            </p>
          </div>

          {/* Cards Layout - Strictly showing 500ml on left and 1.5L on right separately */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
            
            {/* 500ml Isolated Card */}
            <motion.div 
              id="bottle-500ml-teaser-card"
              whileHover={{ y: -8, shadow: '0 30px 60px -15px rgba(0,0,0,0.08)' }}
              className="bg-white hover:border-[#1CB2FF]/20 border border-slate-100 p-8 rounded-[32px] flex flex-col items-center justify-between gap-8 transition-all group relative shadow-sm"
            >
              <div className="absolute top-5 right-5 bg-primary-brand/5 text-primary-brand text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                {t.onTheGo}
              </div>

              {/* Dual Bottles Layout */}
              <div className="h-44 w-auto flex items-center justify-center relative select-none">
                <div className="absolute w-28 h-28 rounded-full bg-secondary-brand/10 filter blur-xl group-hover:bg-secondary-brand/20 transition-all" />
                <img
                  src="/src/assets/images/aabshar_bottles_duo_1779701740908.png"
                  alt="Aabshar 500ml Compact Bottle Layout"
                  className="h-40 w-auto object-contain relative z-10 filter drop-shadow-md hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="space-y-2 mt-4 text-center">
                <span className="text-[#1CB2FF] text-xs font-black uppercase tracking-widest">500ml Active</span>
                <h3 className="text-xl sm:text-2xl font-black text-[#0D263F] font-serif">
                  {language === 'en' ? "500ml Sized Mineral Water" : "500 ملی لیٹر منرل بوتل"}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-xs block leading-relaxed">
                  {t.gymTravelDescription}
                </p>
              </div>

              <div className="pt-6 border-t border-slate-100 w-full space-y-4 text-center">
                <div className="flex justify-between items-center px-4">
                  <span className="text-xs text-slate-400 font-medium">{t.pricePerUnit}</span>
                  <span className="text-xl font-black text-[#0D263F]">{language === 'en' ? "Rs. 35" : "35 روپے"}</span>
                </div>
                
                <button
                  onClick={() => handleOrderRedirect("500ml")}
                  className="w-full bg-[#E7F3FC] hover:bg-primary-brand text-primary-brand hover:text-white font-extrabold py-4 rounded-2xl shadow-sm transition-all select-none"
                >
                  {language === 'en' ? "Order 500ml Carton" : "500 ملی لیٹر کارٹن آرڈر کریں"}
                </button>
              </div>
            </motion.div>

            {/* 1.5L Sized Isolated Card */}
            <motion.div 
              id="bottle-1.5l-teaser-card"
              whileHover={{ y: -8, shadow: '0 30px 60px -15px rgba(0,0,0,0.08)' }}
              className="bg-white hover:border-[#1CB2FF]/20 border border-slate-100 p-8 rounded-[32px] flex flex-col items-center justify-between gap-8 transition-all group relative shadow-sm"
            >
              <div className="absolute top-5 right-5 bg-secondary-brand/10 text-primary-brand text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                {t.familyHome}
              </div>

              {/* Dual Bottles Layout */}
              <div className="h-44 w-auto flex items-center justify-center relative select-none">
                <div className="absolute w-32 h-32 rounded-full bg-primary-brand/5 filter blur-xl group-hover:bg-primary-brand/15 transition-all" />
                <img
                  src="/src/assets/images/aabshar_bottles_duo_1779701740908.png"
                  alt="Aabshar 1.5L Family Sized Bottle Layout"
                  className="h-44 w-auto object-contain relative z-10 filter drop-shadow-xl hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="space-y-2 mt-4 text-center">
                <span className="text-secondary-brand text-xs font-black uppercase tracking-widest">1.5 Liters FAMILY</span>
                <h3 className="text-xl sm:text-2xl font-black text-[#0D263F] font-serif">
                  {language === 'en' ? "1.5L Sized Family Water" : "1.5 لیٹر فیملی بوتل"}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-xs block leading-relaxed">
                  {t.familyOfficeDescription}
                </p>
              </div>

              <div className="pt-6 border-t border-slate-100 w-full space-y-4 text-center">
                <div className="flex justify-between items-center px-4">
                  <span className="text-xs text-slate-400 font-medium">{t.pricePerUnit}</span>
                  <span className="text-xl font-black text-[#0D263F]">{language === 'en' ? "Rs. 75" : "75 روپے"}</span>
                </div>

                <button
                  onClick={() => handleOrderRedirect("1.5L")}
                  className="w-full bg-[#EAFDFD] hover:bg-secondary-brand text-secondary-brand hover:text-[#0D263F] font-extrabold py-4 rounded-2xl shadow-sm transition-all select-none"
                >
                  {language === 'en' ? "Order 1.5L Carton" : "1.5 لیٹر کارٹن آرڈر کریں"}
                </button>
              </div>
            </motion.div>

          </div>

          <div className="pt-4">
            <button
              onClick={() => {
                setActivePage('products');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 group text-primary-brand hover:text-secondary-brand font-black text-sm select-none transition-colors"
            >
              <span>{t.viewFullProducts}</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1.5 transition-transform" />
            </button>
          </div>

        </div>
      </section>


      {/* 1.4 MOUNTAIN SOURCE HIGHLIGHT (GLACIER QUALITY STORY) */}
      <section id="source-story-section" className="py-24 sm:py-32 bg-white relative overflow-hidden">
        
        {/* Abstract light graphic design overlays */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-secondary-brand/5 filter blur-[100px] pointer-events-none" />
        <div className="absolute -left-10 bottom-0 w-[400px] h-[400px] rounded-full bg-primary-brand/5 filter blur-[80px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
            
            {/* Left Graphics column */}
            <div className="lg:col-span-6 relative rounded-[36px] overflow-hidden shadow-2xl group border border-slate-100 bg-[#0D263F]">
              <img
                src="/src/assets/images/karakoram_glacier_peaks_1779696205621.png"
                alt="Aabshar Mountain Peaks and Sourcing Base"
                className="w-full h-[450px] object-cover group-hover:scale-105 transition-transform duration-700 opacity-70"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D263F]/90 via-[#0D263F]/20 to-transparent" />
              
              <div className="absolute bottom-8 left-8 text-white text-left space-y-2">
                <span className="bg-secondary-brand/25 text-secondary-brand text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded inline-block backdrop-blur-sm">
                  {language === 'en' ? "Pristine Swiss Tech" : "سوئس فلٹریشن معیار"}
                </span>
                <p className="font-serif text-xl font-bold">{language === 'en' ? "Standard Quality Hydration" : "صحت بخش پانی کا معیار"}</p>
                <p className="text-xs text-white/60">{language === 'en' ? "Pure Glacier Streams Sourced" : "قدرتی برفانی چشموں کا خالص پانی"}</p>
              </div>
            </div>

            {/* Right Copy column */}
            <div className="lg:col-span-6 text-left space-y-8 flex flex-col items-start">
              
              <div className="bg-[#E7F3FC] text-primary-brand rounded-full px-5 py-2 text-xs font-bold uppercase tracking-wider shadow-sm">
                {t.whereItBegins}
              </div>

              <h2 className="text-3xl sm:text-4.5xl font-extrabold text-[#0D263F] font-serif leading-tight">
                {t.straightFromNature}
              </h2>

              <p className="text-slate-600/90 text-sm sm:text-base leading-relaxed">
                {t.sourceStoryText}
              </p>

              {/* Specifications rows with micro check items */}
              <div className="space-y-6 w-full pt-4">
                
                <div className="flex gap-4 items-start">
                  <div className="w-11 h-11 rounded-2xl bg-[#E7F3FC] flex items-center justify-center text-primary-brand shrink-0 shadow-sm">
                    <Droplets className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-[#0D263F]">{t.mountainOrigin}</h4>
                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mt-0.5">{t.mountainOriginDesc}</p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="w-11 h-11 rounded-2xl bg-[#E3F9FD] flex items-center justify-center text-[#1CB2FF] shrink-0 shadow-sm">
                    <Award className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-[#0D263F]">{t.zeroAdditives}</h4>
                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mt-0.5">{t.zeroAdditivesDesc}</p>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="w-11 h-11 rounded-2xl bg-green-50 flex items-center justify-center text-green-600 shrink-0 shadow-sm">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-[#0D263F]">{t.labTested}</h4>
                    <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mt-0.5">{t.labTestedDesc}</p>
                  </div>
                </div>

              </div>

              <button
                onClick={() => {
                  setActivePage('quality');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="mt-6 inline-flex items-center gap-2 bg-primary-brand hover:bg-[#0B5FA3] hover:shadow-lg hover:shadow-primary-brand/10 transition-all text-white font-bold px-8 py-4 rounded-xl shadow-md select-none"
              >
                <span>{language === 'en' ? "Our Quality Promise" : "پانی کوالٹی معلوم کریں"}</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>

            </div>

          </div>
        </div>
      </section>


      {/* 1.5 FREE COLD CONTAINER COVERS highlight */}
      <section id="delivery-highlight" className="py-24 sm:py-32 bg-gradient-to-r from-primary-brand to-secondary-brand text-white relative overflow-hidden select-none">
        
        {/* Soft floating ripple curves */}
        <div className="absolute -left-16 top-10 w-80 h-80 border border-white/10 rounded-full animate-ripple" style={{ animationDuration: '6s' }} />
        <div className="absolute -right-16 bottom-10 w-96 h-96 border border-white/5 rounded-full animate-ripple-slow" />

        <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-8 text-center space-y-8">
          
          <div className="inline-flex bg-white/10 border border-white/20 p-5 rounded-full animate-bounce" style={{ animationDuration: '3s' }}>
            <Truck className="h-10 w-10 text-white" />
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-serif leading-tight">
            {t.deliveryTitle}
          </h2>

          <p className="text-white/80 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
            {t.deliverySubtitle}
          </p>

          <div className="pt-6">
            <button
              onClick={() => {
                setActivePage('contact');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-white hover:bg-[#F4FAFE] hover:shadow-2xl hover:scale-103 text-primary-brand font-black px-12 py-5 rounded-2xl shadow-xl transition-all"
            >
              {t.deliveryWhHelp}
            </button>
          </div>

          <div className="pt-10 space-y-3">
            <span className="text-xs font-black uppercase tracking-widest text-[#B3E5FF] block">{t.coverageCities}</span>
            <p className="text-sm tracking-wide font-extrabold text-white">
              {t.citiesList}
            </p>
          </div>

        </div>
      </section>


      {/* 1.6 B2B CORPORATE SOLUTIONS TEASER (Glassmorphic) */}
      <section id="b2b-teaser-section" className="py-24 sm:py-32 bg-white text-[#0D263F] relative border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Copy columns (60% equivalent) */}
            <div className="lg:col-span-7 space-y-6 text-left flex flex-col items-start">
              
              <div className="bg-[#EAFDFD] border border-secondary-brand/10 text-secondary-brand rounded-full px-5 py-2 text-xs font-bold uppercase tracking-wider shadow-sm">
                {t.forBusinesses}
              </div>

              <h2 className="text-3xl sm:text-4.5xl font-extrabold font-serif text-[#0D263F] leading-tight">
                {t.yourBrandOurWater}
              </h2>

              <p className="text-slate-600/95 text-sm sm:text-base leading-relaxed">
                {t.b2bTeaserDesc}
              </p>

              <button
                onClick={() => {
                  setActivePage('b2b');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="mt-4 inline-flex items-center gap-2 bg-primary-brand hover:bg-[#0B5FA3] hover:shadow-xl hover:shadow-primary-brand/10 text-white font-extrabold px-8 py-4.5 rounded-2xl shadow-md transition-all select-none"
              >
                <span>{t.exploreB2bBtn}</span>
              </button>

            </div>

            {/* Graphic columns Right (45% equivalent visual) */}
            <div className="lg:col-span-5 relative flex justify-center select-none">
              <div className="absolute w-72 h-72 rounded-full bg-secondary-brand/10 filter blur-[60px] pointer-events-none" />
              
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-100 max-w-sm bg-slate-50 p-2"
              >
                <img
                  src="/src/assets/images/aabshar_b2b_luxury_1779696243785.png"
                  alt="Aabshar custom branded boutique logo hotel bottle"
                  className="w-full h-auto rounded-2xl shadow-inner"
                  referrerPolicy="no-referrer"
                />
                
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary-brand/90 via-primary-brand/30 to-transparent p-5 text-center">
                  <span className="text-[10px] font-black uppercase text-secondary-brand tracking-widest bg-slate-900/85 px-4 py-1.5 rounded-full shadow-md inline-block">
                    {language === 'en' ? "Luxury Custom Sourcing Sample" : "آرڈر نمونہ"}
                  </span>
                </div>
              </motion.div>

            </div>

          </div>
        </div>
      </section>


      {/* 1.7 PREMIUM GLASSMOPHIC TESTIMONIALS */}
      <section id="testimonials-section" className="py-24 sm:py-32 bg-[#F4FAFE] relative overflow-hidden">
        
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 text-center space-y-16">
          
          <div className="space-y-4 max-w-2xl mx-auto">
            <span className="text-primary-brand text-xs font-black uppercase tracking-widest">Testimonials</span>
            <h2 className="text-3xl sm:text-4.5xl font-extrabold font-serif text-[#0D263F] text-center">
              {t.whatCustomersSay}
            </h2>
            <div className="w-14 h-1 bg-gradient-to-r from-primary-brand to-secondary-brand mx-auto rounded-full" />
            <p className="text-slate-500 text-sm sm:text-base leading-relaxed pt-2">
              {t.ratingsSub}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto text-left">
            
            {/* Guest Review Card 1 */}
            <motion.div 
              whileHover={{ y: -6 }}
              className="bg-white/80 border border-white p-8 rounded-3xl flex flex-col justify-between gap-8 h-full shadow-sm hover:shadow-md backdrop-blur-sm transition-all"
            >
              <div className="space-y-4">
                <span className="text-5xl font-serif text-[#1CB2FF] leading-none block h-2">“</span>
                <p className="text-sm sm:text-base text-slate-600/90 leading-relaxed italic pt-2">
                  {language === 'en' 
                    ? "We switched our family hydration to Aabshar and the difference in taste is incredible! It's so clean, light, and we always get our cartons on time without hassle. Free delivery is amazing."
                    : "ہم نے اپنے گھر کے لیے آبشار کا پانی منگوانا شروع کیا اور ذائقہ میں فرق کمال کا پایا! یہ بہت صاف ہے اور گتے کے کارٹن وقت پر بغیر کسی پریشانی کے مل جاتے ہیں۔ ہوم ڈیلیوری سروس لاجواب ہے۔"}
                </p>
              </div>
              
              <div className="flex items-center gap-3 pt-6 border-t border-slate-100">
                <div className="w-10 h-10 rounded-full bg-primary-brand/10 text-primary-brand font-black flex items-center justify-center text-sm uppercase">
                  HA
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-[#0D263F]">{language === 'en' ? "Haris Ahmed" : "حارث احمد"}</h4>
                  <p className="text-[10px] text-slate-400 font-bold">{language === 'en' ? "Model Town, Lahore" : "ماڈل ٹاؤن، لاہور"}</p>
                </div>
                <div className="ml-auto flex gap-0.5 text-yellow-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
                </div>
              </div>
            </motion.div>

            {/* Corporate Review Card 2 */}
            <motion.div 
              whileHover={{ y: -6 }}
              className="bg-white/80 border border-white p-8 rounded-3xl flex flex-col justify-between gap-8 h-full shadow-sm hover:shadow-md backdrop-blur-sm transition-all"
            >
              <div className="space-y-4">
                <span className="text-5xl font-serif text-[#1CB2FF] leading-none block h-2">“</span>
                <p className="text-sm sm:text-base text-slate-600/90 leading-relaxed italic pt-2">
                  {language === 'en'
                    ? "Aabshar custom printed bottles for our hotel rooms has elevated our brand identity to a luxury peak. Guests often praise the elegance. Ordering bulk is so easy."
                    : "ہوٹل کے مہمانوں کے کمروں کے لیے آبشار کی کسٹم بوتلیں استعمال کر رہے ہیں۔ اس سے ہمارے برانڈ کسٹمرز پر لاجواب تاثر جاتا ہے۔ بلک ریٹ بھی بہت مناسب دیتے ہیں۔"}
                </p>
              </div>

              <div className="flex items-center gap-3 pt-6 border-t border-slate-100">
                <div className="w-10 h-10 rounded-full bg-secondary-brand/15 text-primary-brand font-black flex items-center justify-center text-sm uppercase">
                  SN
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-[#0D263F]">{language === 'en' ? "Sidra Naeem" : "سدرہ نعیم"}</h4>
                  <p className="text-[10px] text-slate-400 font-bold">{language === 'en' ? "CEO, Pearl Suites, Islamabad" : "سی ای او، پرل سویٹس، اسلام آباد"}</p>
                </div>
                <div className="ml-auto flex gap-0.5 text-yellow-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
                </div>
              </div>
            </motion.div>

            {/* Mother Review Card 3 */}
            <motion.div 
              whileHover={{ y: -6 }}
              className="bg-white/80 border border-white p-8 rounded-3xl flex flex-col justify-between gap-8 h-full shadow-sm hover:shadow-md backdrop-blur-sm transition-all"
            >
              <div className="space-y-4">
                <span className="text-5xl font-serif text-[#1CB2FF] leading-none block h-2">“</span>
                <p className="text-sm sm:text-base text-slate-600/90 leading-relaxed italic pt-2">
                  {language === 'en'
                    ? "Since Aabshar has an ideal TDS of 135 ppm, my kids feel active, digestion is fully secure, and the taste is delightfully sweet and natural. Highly recommended across Karachi!"
                    : "آبشار کا ٹی ڈی ایس 135 معدنیاتی معیار کا مثالی پیمانہ ہے۔ میرے بچے اسے شوق سے پیتے ہیں اور پیٹ کے تمام مسائل ختم ہوچکے ہیں۔ لاہور اور کراچی والوں کو ضرور ٹرائی کرنا چاہیے۔"}
                </p>
              </div>

              <div className="flex items-center gap-3 pt-6 border-t border-slate-100">
                <div className="w-10 h-10 rounded-full bg-primary-brand/10 text-primary-brand font-black flex items-center justify-center text-sm uppercase">
                  MK
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-[#0D263F]">{language === 'en' ? "Maryam Khan" : "مریم خان"}</h4>
                  <p className="text-[10px] text-slate-400 font-bold">{language === 'en' ? "DHA, Karachi" : "ڈی ایچ اے، کراچی"}</p>
                </div>
                <div className="ml-auto flex gap-0.5 text-yellow-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
                </div>
              </div>
            </motion.div>

          </div>

        </div>
      </section>


      {/* 1.8 INSTAGRAM / LIFESTYLE GALLERY */}
      <section id="social-gallery" className="py-20 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 space-y-10">
          
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-black font-serif text-[#0D263F] tracking-tight">
              {t.socialTitle}
            </h2>
            <p className="text-[10px] text-slate-450 tracking-widest uppercase font-extrabold">
              {t.socialSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 select-none">
            {instagramImages.map((img, index) => (
              <div
                key={index}
                className="group relative rounded-2xl overflow-hidden aspect-square border border-slate-100 hover:shadow-lg transition-all"
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Glass Filter hover */}
                <div className="absolute inset-0 bg-[#0D263F]/40 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-4 text-white transition-all backdrop-blur-[2px]">
                  <span className="flex items-center gap-1.5 text-xs font-black">
                    <Heart className="h-4.5 w-4.5 fill-white text-white" /> 184
                  </span>
                  <span className="flex items-center gap-1.5 text-xs font-black">
                    <MessageSquare className="h-4.5 w-4.5 fill-white text-white" /> 16
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

    </div>
  );
};
