/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { 
  Phone, 
  MessageCircle, 
  Check, 
  Award, 
  Recycle, 
  ShieldAlert, 
  BadgeCheck, 
  FileText, 
  Sparkles,
  ShoppingBag,
  Info 
} from 'lucide-react';

interface ProductsViewProps {
  language: Language;
}

export const ProductsView: React.FC<ProductsViewProps> = ({ language }) => {
  const t = translations[language];

  // Dynamic active tab for sizes
  const [activeSize, setActiveSize] = useState<'500ml' | '1.5L'>('500ml');

  // Pack selection states
  const [selectedPack500, setSelectedPack500] = useState(2); // Default to Carton (24-pack)
  const [selectedPack1500, setSelectedPack1500] = useState(2); // Default to Carton (12-pack)

  const packs500 = [
    { nameEn: "Single Bottle", nameUr: "ایک بوتل", count: 1, price: 35, savingsEn: "No savings", savingsUr: "رعایت دستیاب نہیں" },
    { nameEn: "12-Bottle Pack", nameUr: "12 بوتلوں کا پیک", count: 12, price: 390, savingsEn: "Save Rs. 30", savingsUr: "30 روپے بچائیں" },
    { nameEn: "24-Bottle Carton", nameUr: "24 بوتلوں کا کارٹن", count: 24, price: 720, savingsEn: "Save Rs. 120 (Best Seller)", savingsUr: "120 روپے بچت (سب سے مقبول)" },
  ];

  const packs1500 = [
    { nameEn: "Single Bottle", nameUr: "ایک بوتل", count: 1, price: 75, savingsEn: "No savings", savingsUr: "رعایت دستیاب نہیں" },
    { nameEn: "6-Bottle Bundle", nameUr: "6 بوتلوں کا بنڈل", count: 6, price: 420, savingsEn: "Save Rs. 30", savingsUr: "30 روپے بچائیں" },
    { nameEn: "12-Bottle Carton", nameUr: "12 بوتلوں کا کارٹن", count: 12, price: 780, savingsEn: "Save Rs. 120 (Best Value)", savingsUr: "120 روپے بچت (سب سے اہم)" },
  ];

  const handleOrderSubmit = (size: string, packName: string, count: number, price: number) => {
    const text = language === 'en'
      ? `Hello Aabshar Sourcing! I want to order "${size} - ${packName} (${count} bottles)" for Rs. ${price}. Please confirm availability and delivery slots.`
      : `سلام علیکم آبشار! مجھے منرل واٹر "${size} - ${packName} (${count} بوتلیں)" کا آرڈر دینا ہے۔ کل رقم: ${price} روپے۔ کائنڈلی تصدیق کریں۔`;
    window.open(`https://wa.me/923004752668?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div id="products-view" className={`pt-20 bg-[#F4FAFE] ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 2.1 MODERN GLACIER HERO */}
      <section id="products-hero" className="relative py-20 bg-gradient-to-b from-[#E7F3FC] via-[#F6FBFF] to-[#F4FAFE] text-center overflow-hidden border-b border-slate-100">
        <div className="absolute inset-0 z-0 pointer-events-none select-none">
          <img
            src="/src/assets/images/karakoram_glacier_peaks_1779696205621.png"
            alt="Pristine mountain streams Pakistan"
            className="w-full h-full object-cover opacity-[0.10] filter blur-[1px]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#F4FAFE] via-transparent to-transparent" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-6 space-y-4">
          <span className="text-primary-brand text-xs font-black uppercase tracking-widest">{t.navProducts}</span>
          <h1 className="text-3xl sm:text-5.5.xl font-extrabold font-serif text-[#0D263F] tracking-tight">
            {t.pageProductHeading}
          </h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
            {t.pageProductSub}
          </p>
        </div>
      </section>

      {/* 2.2 HIGH-END COHESIVE INTERACTIVE TABS */}
      <section id="interactive-product-section" className="py-12 max-w-7xl mx-auto px-6">
        
        {/* Flat Glass Selector */}
        <div className="flex justify-center mb-16 select-none">
          <div className="bg-white/80 border border-slate-150 p-1.5 rounded-2xl flex items-center shadow-md backdrop-blur-md">
            
            <button
              onClick={() => setActiveSize('500ml')}
              className={`flex items-center gap-2 px-8 py-3.5 rounded-xl text-sm font-extrabold transition-all duration-300 ${
                activeSize === '500ml'
                  ? 'bg-primary-brand text-white shadow-lg shadow-primary-brand/15 scale-102'
                  : 'text-[#0D263F] hover:bg-slate-50'
              }`}
            >
              <span>💧</span>
              <span>{language === 'en' ? "500ml Personal Sized" : "500 ملی لیٹر بوتل"}</span>
            </button>

            <button
              onClick={() => setActiveSize('1.5L')}
              className={`flex items-center gap-2 px-8 py-3.5 rounded-xl text-sm font-extrabold transition-all duration-300 ${
                activeSize === '1.5L'
                  ? 'bg-primary-brand text-white shadow-lg shadow-primary-brand/15 scale-102'
                  : 'text-[#0D263F] hover:bg-slate-50'
              }`}
            >
              <span>🌊</span>
              <span>{language === 'en' ? "1.5L Family Sized" : "1.5 لیٹر فیملی بوتل"}</span>
            </button>

          </div>
        </div>

        {/* Dynamic Multi-Section Switch Area */}
        <div id="product-panel-container" className="min-h-[500px]">
          <AnimatePresence mode="wait">
            {activeSize === '500ml' ? (
              
              /* 500ML SECTION */
              <motion.div
                key="500ml-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-slate-100 relative"
              >
                
                {/* Visual rendering Column (Left) (Showing ONLY 500ml bottle) */}
                <div className="lg:col-span-6 flex flex-col items-center justify-center relative bg-[#F4FAFE] rounded-2xl p-8 border border-slate-50">
                  <span className="absolute top-5 left-5 bg-primary-brand text-white text-[10px] font-black uppercase tracking-wider px-3.5 py-1.5 rounded-full select-none">
                    {t.onTheGo}
                  </span>

                  {/* Strictly displays the pristine water bottle duo */}
                  <div className="absolute w-60 h-60 rounded-full bg-secondary-brand/10 filter blur-2xl pointer-events-none animate-pulse" />
                  <img
                    src="/src/assets/images/aabshar_bottles_duo_1779701740908.png"
                    alt="Aabshar 500ml Compact Premium Mineral Bottle"
                    className="h-64 object-contain filter drop-shadow-2xl relative z-10 hover:scale-105 transition-transform animate-float-medium"
                    referrerPolicy="no-referrer"
                  />

                  {/* Specifications Details layout in columns directly underneath */}
                  <div className="mt-8 w-full border-t border-slate-100 pt-6 text-xs text-slate-500 select-none space-y-3.5">
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableVolume}</span>
                      <span className="font-black text-[#0D263F]">500ml</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableTds}</span>
                      <span className="font-black text-primary-brand">135 ppm (TDS Calibrated)</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableSource}</span>
                      <span className="font-black text-[#0D263F]">{language === 'en' ? "Natural Mountain Springs" : "قدرتی پہاڑی چشمے"}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableCap}</span>
                      <span className="font-black text-[#0D263F]">{language === 'en' ? "Tamper-Evident Safety Seal" : "ایئر ٹائٹ جراثیم کش سیل"}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="font-extrabold text-slate-400">{t.specTablePackaging}</span>
                      <span className="font-black text-[#0D263F]">Class 1 Virgin Recyclable PET</span>
                    </div>
                  </div>

                </div>

                {/* E-commerce details Column (Right) */}
                <div className="lg:col-span-6 text-left space-y-8 flex flex-col justify-between h-full">
                  <div>
                    <div className="flex items-center gap-2 mb-2 text-[#1CB2FF] font-black text-xs uppercase tracking-widest">
                      <Sparkles className="h-4 w-4" />
                      <span>{language === 'en' ? "Active Compact Collection" : "پرسنل فٹنس کلیکشن"}</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0D263F] font-serif">
                      {language === 'en' ? "Aabshar 500ml Premium Sourced" : "آبشار 500 ملی لیٹر منرل بوتل"}
                    </h2>
                    <p className="text-slate-500 text-sm sm:text-base mt-4 leading-relaxed font-normal">
                      {t.gymTravelDescription}
                    </p>
                  </div>

                  {/* Pack Selector layout */}
                  <div className="w-full space-y-4">
                    <h3 className="text-xs font-black text-primary-brand uppercase tracking-wider block">
                      {t.packSizesAvailable}
                    </h3>
                    
                    <div className="grid grid-cols-3 gap-3 w-full">
                      {packs500.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSelectedPack500(idx)}
                          className={`flex flex-col items-center justify-center p-3.5 rounded-2xl border text-center transition-all ${
                            selectedPack500 === idx
                              ? 'border-primary-brand bg-primary-brand/5 text-primary-brand font-black shadow-sm'
                              : 'border-slate-100 hover:border-slate-300 text-slate-500 bg-slate-50/50'
                          }`}
                        >
                          <span className="text-xs font-extrabold tracking-tight">
                            {language === 'en' ? p.nameEn : p.nameUr}
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Costing Breakdowns */}
                    <div className="bg-[#F4FAFE] rounded-2xl p-5 border border-slate-50 space-y-3.5 select-none">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400 font-bold">Calculation Strategy:</span>
                        <span className="font-black text-primary-brand">
                          {packs500[selectedPack500].count} X Rs. 30
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-baseline border-t border-slate-200/50 pt-3">
                        <span className="text-xs text-[#0D263F] font-black">Grand Total:</span>
                        <span className="text-2xl font-black text-[#0D263F]">Rs. {packs500[selectedPack500].price}</span>
                      </div>

                      <div className="text-[10px] text-green-600 font-extrabold bg-green-50 px-3 py-1.5 rounded-lg inline-flex items-center gap-1.5">
                        <BadgeCheck className="h-3.5 w-3.5" />
                        <span>{language === 'en' ? packs500[selectedPack500].savingsEn : packs500[selectedPack500].savingsUr}</span>
                      </div>
                    </div>
                  </div>

                  {/* Checkouts Block */}
                  <div className="flex flex-col sm:flex-row gap-4 w-full pt-2">
                    <button
                      onClick={() => handleOrderSubmit(
                        "500ml Size Layout",
                        packs500[selectedPack500].nameEn,
                        packs500[selectedPack500].count,
                        packs500[selectedPack500].price
                      )}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 hover:shadow-lg hover:shadow-green-100 transition-all font-black text-white py-4.5 px-6 rounded-2xl cursor-pointer"
                    >
                      <MessageCircle className="h-5 w-5 fill-white text-green-600" />
                      <span>{t.whatsappOrder}</span>
                    </button>

                    <a
                      href="tel:+923051999897"
                      className="flex items-center justify-center gap-2 bg-primary-brand hover:bg-[#0B5FA3] hover:shadow-lg hover:shadow-primary-brand/15 transition-all font-black text-white py-4.5 px-6 rounded-2xl text-sm"
                    >
                      <Phone className="h-4.5 w-4.5" />
                      <span>{t.btnCallToOrder}</span>
                    </a>
                  </div>

                </div>

              </motion.div>
            ) : (
              
              /* 1.5L SECTION */
              <motion.div
                key="1.5l-view"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-slate-100 relative"
              >
                
                {/* Visual rendering Column (Left) (Showing ONLY 1.5L bottle) */}
                <div className="lg:col-span-6 flex flex-col items-center justify-center relative bg-[#F4FAFE] rounded-2xl p-8 border border-slate-50">
                  <span className="absolute top-5 left-5 bg-secondary-brand/20 text-[#0D263F] text-[10px] font-black uppercase tracking-wider px-3.5 py-1.5 rounded-full select-none">
                    {t.familyHome}
                  </span>

                  {/* Strictly displays the pristine family water bottle duo */}
                  <div className="absolute w-64 h-64 rounded-full bg-primary-brand/5 filter blur-2xl pointer-events-none animate-pulse" />
                  <img
                    src="/src/assets/images/aabshar_bottles_duo_1779701740908.png"
                    alt="Aabshar 1.5L Family Dining Premium Mineral Bottle"
                    className="h-[270px] object-contain filter drop-shadow-2xl relative z-10 hover:scale-105 transition-transform animate-float-slow"
                    referrerPolicy="no-referrer"
                  />

                  {/* Specifications Details */}
                  <div className="mt-8 w-full border-t border-slate-100 pt-6 text-xs text-slate-500 select-none space-y-3.5">
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableVolume}</span>
                      <span className="font-black text-[#0D263F]">1.5 Liters (1500ml)</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableTds}</span>
                      <span className="font-black text-primary-brand">135 ppm (TDS Calibrated)</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableSource}</span>
                      <span className="font-black text-[#0D263F]">{language === 'en' ? "Natural Mountain Springs" : "قدرتی پہاڑی چشمے"}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-50">
                      <span className="font-extrabold text-slate-400">{t.specTableCap}</span>
                      <span className="font-black text-[#0D263F]">{language === 'en' ? "Heavy Duty Leak-Proof Seal" : "ڈبل گارڈ حفاظتی ڈھکن"}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="font-extrabold text-slate-400">{t.specTablePackaging}</span>
                      <span className="font-black text-[#0D263F]">Class 1 Virgin Recyclable PET</span>
                    </div>
                  </div>

                </div>

                {/* E-commerce details Column (Right) */}
                <div className="lg:col-span-6 text-left space-y-8 flex flex-col justify-between h-full">
                  <div>
                    <div className="flex items-center gap-2 mb-2 text-[#1CB2FF] font-black text-xs uppercase tracking-widest">
                      <Sparkles className="h-4 w-4" />
                      <span>{language === 'en' ? "Luxury Home & Dining Edition" : "فیملی ڈائننگ ایڈیشن"}</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0D263F] font-serif">
                      {language === 'en' ? "Aabshar 1.5L Family Sized Sourced" : "آبشار 1.5 لیٹر فیملی بوتل"}
                    </h2>
                    <p className="text-slate-500 text-sm sm:text-base mt-4 leading-relaxed font-normal">
                      {t.familyOfficeDescription}
                    </p>
                  </div>

                  {/* Pack Selector */}
                  <div className="w-full space-y-4">
                    <h3 className="text-xs font-black text-primary-brand uppercase tracking-wider block">
                      {t.packSizesAvailable}
                    </h3>
                    
                    <div className="grid grid-cols-3 gap-3 w-full">
                      {packs1500.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSelectedPack1500(idx)}
                          className={`flex flex-col items-center justify-center p-3.5 rounded-2xl border text-center transition-all ${
                            selectedPack1500 === idx
                              ? 'border-primary-brand bg-primary-brand/5 text-primary-brand font-black shadow-sm'
                              : 'border-slate-100 hover:border-slate-300 text-slate-500 bg-slate-50/50'
                          }`}
                        >
                          <span className="text-xs font-extrabold tracking-tight">
                            {language === 'en' ? p.nameEn : p.nameUr}
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Costing Breakdowns */}
                    <div className="bg-[#F4FAFE] rounded-2xl p-5 border border-slate-50 space-y-3.5 select-none">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400 font-bold">Calculation Strategy:</span>
                        <span className="font-black text-primary-brand">
                          {packs1500[selectedPack1500].count} X Rs. 65
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-baseline border-t border-slate-200/50 pt-3">
                        <span className="text-xs text-[#0D263F] font-black">Grand Total:</span>
                        <span className="text-2xl font-black text-[#0D263F]">Rs. {packs1500[selectedPack1500].price}</span>
                      </div>

                      <div className="text-[10px] text-green-600 font-extrabold bg-green-50 px-3 py-1.5 rounded-lg inline-flex items-center gap-1.5">
                        <BadgeCheck className="h-3.5 w-3.5" />
                        <span>{language === 'en' ? packs1500[selectedPack1500].savingsEn : packs1500[selectedPack1500].savingsUr}</span>
                      </div>
                    </div>
                  </div>

                  {/* Checkouts Block */}
                  <div className="flex flex-col sm:flex-row gap-4 w-full pt-2">
                    <button
                      onClick={() => handleOrderSubmit(
                        "1.5L Family Sized",
                        packs1500[selectedPack1500].nameEn,
                        packs1500[selectedPack1500].count,
                        packs1500[selectedPack1500].price
                      )}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 hover:shadow-lg hover:shadow-green-100 transition-all font-black text-white py-4.5 px-6 rounded-2xl cursor-pointer"
                    >
                      <MessageCircle className="h-5 w-5 fill-white text-green-600" />
                      <span>{t.whatsappOrder}</span>
                    </button>

                    <button
                      onClick={() => handleOrderSubmit("1.5L Bulk Sized", "Bulk inquiry request", 100, 7500)}
                      className="flex items-center justify-center gap-2 bg-primary-brand hover:bg-[#0B5FA3] hover:shadow-lg hover:shadow-primary-brand/15 transition-all font-black text-white py-4.5 px-6 rounded-2xl text-sm"
                    >
                      <span>{t.btnBulkInquiry}</span>
                    </button>
                  </div>

                </div>

              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </section>

      {/* 2.3 PACKAGING HIGHLIGHTS */}
      <section id="packaging-highlights" className="py-24 sm:py-32 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 text-center space-y-16">
          
          <div className="space-y-4 max-w-2xl mx-auto">
            <span className="text-primary-brand text-xs font-black uppercase tracking-widest">Quality Excellence</span>
            <h2 className="text-3xl sm:text-4.5xl font-extrabold text-[#0D263F] font-serif">
              {t.packagingHeading}
            </h2>
            <div className="w-14 h-1 bg-gradient-to-r from-primary-brand to-secondary-brand mx-auto rounded-full" />
            <p className="text-slate-500 text-sm sm:text-base leading-relaxed pt-2">
              {t.packagingSub}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
            
            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-blue-100 flex items-center justify-center text-primary-brand shadow-sm">
                <Recycle className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{t.recyclablePet}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">{t.recyclablePetDesc}</p>
            </div>

            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-green-100 flex items-center justify-center text-green-600 shadow-sm">
                <Award className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{t.bpaFree}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">{t.bpaFreeDesc}</p>
            </div>

            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-cyan-100 flex items-center justify-center text-cyan-600 shadow-sm">
                <BadgeCheck className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{t.tamperCap}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">{t.tamperCapDesc}</p>
            </div>

            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-purple-100 flex items-center justify-center text-purple-600 shadow-sm">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{t.easyGrip}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">{t.easyGripDesc}</p>
            </div>

            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-orange-100 flex items-center justify-center text-orange-600 shadow-sm">
                <FileText className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{language === 'en' ? "Traceable Purity QR" : "تکنیکی لیب رپورٹ کیو آر"}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">
                {language === 'en' ? "Verify batch composition details instantly using QR verification." : "بوتل پر لگے کیو آر کو اسکین کر کے فوری طور پر اس سیزن کی کیمیکل رپورٹ دیکھیں۔"}
              </p>
            </div>

            <div className="bg-[#F4FAFE] p-8 rounded-3xl border border-slate-50 space-y-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 rounded-2xl bg-teal-100 flex items-center justify-center text-teal-600 shadow-sm">
                <Check className="h-5 w-5" />
              </div>
              <h3 className="font-extrabold text-lg text-[#0D263F]">{language === 'en' ? "Printed Chemical Minerals" : "معدنیات کی فی بوتل لسٹ"}</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed font-normal">
                {language === 'en' ? "Chemical elements listed clearly including TDS, pH and minerals." : "بوتل کے پیچھے منرلز کی لسٹ جیسے کیلشیم، میگنیشیم، سوڈیم واضح پرنٹڈ ہیں۔"}
              </p>
            </div>

          </div>

        </div>
      </section>


      {/* 2.4 BULK & WHOLESALE CTA */}
      <section id="bulk-distributor-wholesale" className="py-24 bg-[#0D263F] text-white relative select-none">
        
        {/* Design Accents */}
        <div className="absolute top-0 right-1/4 w-80 h-80 rounded-full bg-primary-brand/10 filter blur-[90px] pointer-events-none" />

        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12 bg-white/5 border border-white/10 p-10 sm:p-14 rounded-[36px] backdrop-blur-md">
            
            <div className="space-y-4 max-w-xl text-left">
              <div className="inline-flex items-center gap-1.5 bg-[#1CB2FF]/20 text-secondary-brand px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">
                <Info className="h-3.5 w-3.5" />
                <span>Bulk Distribution Wholesales</span>
              </div>
              <h2 className="text-3xl sm:text-4.5xl font-extrabold font-serif text-[#1CB2FF] leading-tight">
                {t.wholesaleCardTitle}
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                {t.wholesaleSubtitle}
              </p>
            </div>

            <div className="w-full lg:w-auto shrink-0">
              <a
                href={`https://wa.me/923004752668?text=${encodeURIComponent(
                  language === 'en'
                    ? "Hello Aabshar! I am a retailer/distributor and I'm interested in bulk wholesale rates for 500ml & 1.5L. Please share price grids."
                    : "اسلام علیکم آبشار! میں ریٹیل کمپنی ہوں اور مجھے 500 ملی لیٹر اور 1.5 لیٹر پانی کے بلک ہول سیل ریٹس معلوم کرنے ہیں۔"
                )}`}
                target="_blank"
                rel="noreferrer"
                className="block w-full text-center bg-secondary-brand hover:bg-[#1CB2FF] text-[#0D263F] hover:text-[#0D263F] font-extrabold px-10 py-5 rounded-2xl shadow-xl transition-all cursor-pointer hover:-translate-y-1"
              >
                {t.wholesaleCardBtn}
              </a>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
