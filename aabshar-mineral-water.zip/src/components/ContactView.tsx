/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { Phone, MessageCircle, Mail, MapPin, Send, HelpCircle, FileCheck, Landmark } from 'lucide-react';

interface ContactViewProps {
  language: Language;
}

export const ContactView: React.FC<ContactViewProps> = ({ language }) => {
  const t = translations[language];

  // Domestic Order form state
  const [orderName, setOrderName] = useState('');
  const [orderPhone, setOrderPhone] = useState('');
  const [orderCity, setOrderCity] = useState('Islamabad');
  const [orderProduct, setOrderProduct] = useState('Both (500ml & 1.5L Cartons)');
  const [orderQty, setOrderQty] = useState('1');
  const [orderAddress, setOrderAddress] = useState('');
  const [orderSpecial, setOrderSpecial] = useState('');
  const [isSubmitSuccessful, setIsSubmitSuccessful] = useState(false);

  // Distributor Inquiry form state
  const [distName, setDistName] = useState('');
  const [distCity, setDistCity] = useState('');
  const [distPhone, setDistPhone] = useState('');
  const [distType, setDistType] = useState('Supermarket');
  const [isDistSubmitSuccessful, setIsDistSubmitSuccessful] = useState(false);

  // Standard Cities
  const activeCitiesList = ["Islamabad", "Rawalpindi", "Fateh Jang"];

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitSuccessful(true);

    const messageText = language === 'en'
      ? `Aabshar New Order Intake:\n\nName: ${orderName}\nPhone: ${orderPhone}\nCity: ${orderCity}\nProduct: ${orderProduct}\nQty: ${orderQty} Cartons\nAddress: ${orderAddress}\nSpecial: ${orderSpecial}`
      : `آبشار پانی نیا آرڈر فارم:\n\nگراہک نام: ${orderName}\nرابطہ نمبر: ${orderPhone}\nشہر: ${orderCity}\nپروڈکٹ حجم: ${orderProduct}\nتعداد: ${orderQty} کارٹن\nمکمل پتہ: ${orderAddress}\nہدایت: ${orderSpecial}`;

    setTimeout(() => {
      window.open(`https://wa.me/923051999897?text=${encodeURIComponent(messageText)}`, '_blank');
      setIsSubmitSuccessful(false);
    }, 1800);
  };

  const handleDistributorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsDistSubmitSuccessful(true);

    const messageText = language === 'en'
      ? `Aabshar Distributor Partnership Request:\n\nName: ${distName}\nCity: ${distCity}\nPhone: ${distPhone}\nBusiness: ${distType}`
      : `آبشار ڈسٹریبیوٹر تجارتی پارٹنر انکوائری:\n\nنام: ${distName}\nشہر: ${distCity}\nنمبر: ${distPhone}\nکاروبار کی قسم: ${distType}`;

    setTimeout(() => {
      window.open(`https://wa.me/923051999897?text=${encodeURIComponent(messageText)}`, '_blank');
      setIsDistSubmitSuccessful(false);
    }, 1800);
  };

  return (
    <div className={`pt-20 bg-accent-brand ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 7.1 PAGE HERO */}
      <section className="relative py-20 bg-gradient-to-b from-[#E7F3FC] via-[#F6FBFF] to-accent-brand text-text-primary text-center overflow-hidden select-none border-b border-primary-brand/10">
        
        {/* Glacier Peak Background Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/karakoram_glacier_peaks_1779696205621.png"
            alt="Pure glacier mountain springs, Naran Kaghan"
            className="w-full h-full object-cover opacity-25"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-accent-brand via-transparent to-transparent" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <h1 className="text-3xl sm:text-5xl font-black font-serif text-primary-brand drop-shadow-sm">
            {t.contactHeroHeading}
          </h1>
          <p className="text-text-primary/75 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
            {t.contactHeroSub}
          </p>
        </div>
      </section>


      {/* 7.2 3-COLUMN CONTACT OPTIONS */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto text-left">
          
          {/* Col 1 */}
          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm flex flex-col items-start gap-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-green-600">
              <MessageCircle className="h-6 w-6 fill-green-600 text-transparent" />
            </div>
            <h3 className="font-black text-lg text-primary-brand font-serif">{t.columnWhTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.columnWhText}</p>
            
            <a
              href="https://wa.me/923051999897"
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold p-3 px-5 rounded-xl text-xs"
            >
              <span>{t.whatsappOrder}</span>
            </a>
            
            <div className="pt-2 border-t border-primary-brand/5 w-full text-[10px] text-text-primary/55 font-bold">
              {t.columnWhHours}
            </div>
          </div>

          {/* Col 2 */}
          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm flex flex-col items-start gap-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-primary-brand">
              <Phone className="h-6 w-6" />
            </div>
            <h3 className="font-black text-lg text-primary-brand font-serif">{t.columnCallTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.columnCallText}</p>
            
            <a
              href="tel:+923051999897"
              className="mt-2 inline-flex items-center gap-2 bg-primary-brand hover:bg-primary-brand/90 text-white font-bold p-3 px-5 rounded-xl text-xs"
            >
              <span>📞 +92 305 1999897</span>
            </a>

            <div className="pt-2 border-t border-primary-brand/5 w-full text-[10px] text-text-primary/55 font-bold">
              {t.columnCallHours}
            </div>
          </div>

          {/* Col 3 */}
          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm flex flex-col items-start gap-4 hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700">
              <Mail className="h-6 w-6" />
            </div>
            <h3 className="font-black text-lg text-primary-brand font-serif">{t.columnEmailTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.columnEmailText}</p>
            
            <a
              href="mailto:orders@aabshar.com"
              className="mt-2 inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold p-3 px-5 rounded-xl text-xs"
            >
              <span>✉️ orders@aabshar.com</span>
            </a>

            <div className="pt-2 border-t border-primary-brand/5 w-full text-[10px] text-text-primary/55 font-bold">
              {t.columnEmailAddress}
            </div>
          </div>

        </div>
      </section>


      {/* 7.3 ONLINE ORDER FORM */}
      <section className="py-24 bg-white border-t border-primary-brand/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl p-6 sm:p-12 border border-primary-brand/5 shadow-2xl relative">
            
            <div className="text-center space-y-2 mb-10 select-none">
              <div className="inline-flex bg-primary-brand/5 border border-primary-brand/10 p-3 rounded-full text-primary-brand">
                <Landmark className="h-6 w-6" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black font-serif text-primary-brand">
                {t.orderFormTitle}
              </h2>
              <p className="text-xs text-text-primary/50 max-w-sm mx-auto">
                {language === 'en' ? "Secure free fast shipping. Cash on Delivery (COD) accepted across Lahore, Karachi, Islamabad..." : "آرڈر جمع کرنے کے بعد ڈیلیوری بوائے آپ سے رابطہ کر کے وقت کنفرم کرے گا۔"}
              </p>
            </div>

            <form onSubmit={handleOrderSubmit} className="space-y-6 text-left">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formFullName}</label>
                  <input
                    type="text"
                    required
                    value={orderName}
                    onChange={(e) => setOrderName(e.target.value)}
                    placeholder="e.g., Haris Ahmed"
                    className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formPhone}</label>
                  <input
                    type="tel"
                    required
                    value={orderPhone}
                    onChange={(e) => setOrderPhone(e.target.value)}
                    placeholder="e.g., 0305-1999897"
                    className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formCitySelect}</label>
                  <select
                    value={orderCity}
                    onChange={(e) => setOrderCity(e.target.value)}
                    className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand bg-accent-brand/45 text-sm outline-none cursor-pointer"
                  >
                    {activeCitiesList.map((c, i) => (
                      <option key={i} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formProductSelect}</label>
                  <select
                    value={orderProduct}
                    onChange={(e) => setOrderProduct(e.target.value)}
                    className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand bg-accent-brand/45 text-sm outline-none cursor-pointer"
                  >
                    <option value="500ml Compact Bottles">{language === 'en' ? "500ml Bottles Carton (24-pack)" : "500 ملی لیٹر بوتل ڈبے"}</option>
                    <option value="1.5L Family Bottles">{language === 'en' ? "1.5L Bottles Carton (12-pack)" : "1.5 لیٹر بوتل ڈبے"}</option>
                    <option value="Both Sized Cartons">{language === 'en' ? "Both Sized Cartons Bundle" : "دونوں حجم مکس کارٹن"}</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formQty}</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={orderQty}
                  onChange={(e) => setOrderQty(e.target.value)}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{orderCity} {language === 'en' ? "Delivery Address" : "کا ڈور اسٹیپ پتہ"}</label>
                <textarea
                  required
                  value={orderAddress}
                  onChange={(e) => setOrderAddress(e.target.value)}
                  rows={3}
                  placeholder={language === 'en' ? "Provide house, block, housing society landmark in Lahore / Karachi..." : "مکان نمبر، گلی نمبر، فلیٹ نام، بلاک، سوسائٹی فیز اور مشہور قریبی چوک..."}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formSpecialInstruct}</label>
                <input
                  type="text"
                  value={orderSpecial}
                  onChange={(e) => setOrderSpecial(e.target.value)}
                  placeholder={language === 'en' ? "e.g., Deliver afternoon before 4PM or ring phone bell" : "مثال: دوپہر 2 بجے سے پہلے لائیں"}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>

              {isSubmitSuccessful ? (
                <div className="p-4 bg-green-500/10 border border-green-500/30 text-green-700 font-bold rounded-xl text-center text-xs sm:text-sm animate-pulse select-none">
                  ✓ {t.subSuccessDesc}
                </div>
              ) : (
                <button
                  type="submit"
                  className="w-full bg-green-600 hover:bg-green-500 hover:scale-102 transition-all text-white font-black py-4 rounded-xl shadow-lg shadow-green-900/10 cursor-pointer text-center flex items-center justify-center gap-2"
                >
                  <MessageCircle className="h-5 w-5 fill-white text-green-600" />
                  <span>{t.btnSubmitOrder}</span>
                </button>
              )}

            </form>

          </div>
        </div>
      </section>


      {/* 7.4 DISTRIBUTOR & RETAILER INQUIRY */}
      <section className="py-24 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-12 border border-primary-brand/5 shadow-xl relative text-left">
          
          <div className="text-center space-y-2 mb-10 select-none">
            <div className="inline-flex bg-primary-brand/5 border border-primary-brand/10 p-3 rounded-full text-primary-brand">
              <FileCheck className="h-6 w-6" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-serif text-primary-brand">
              {t.distributorFormTitle}
            </h2>
            <p className="text-xs text-text-primary/50 max-w-xl mx-auto leading-relaxed">
              {t.distributorSectionTxt}
            </p>
          </div>

          <form onSubmit={handleDistributorSubmit} className="space-y-6">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formFullName}</label>
                <input
                  type="text"
                  required
                  value={distName}
                  onChange={(e) => setDistName(e.target.value)}
                  placeholder="e.g., Haris Ahmed"
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formPhone}</label>
                <input
                  type="tel"
                  required
                  value={distPhone}
                  onChange={(e) => setDistPhone(e.target.value)}
                  placeholder="e.g., 0305-1999897"
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formCitySelect}</label>
                <input
                  type="text"
                  required
                  value={distCity}
                  onChange={(e) => setDistCity(e.target.value)}
                  placeholder="e.g., Peshawar, Gujranwala"
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand focus:ring-1 focus:ring-secondary-brand bg-accent-brand/45 text-sm outline-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black text-primary-brand uppercase tracking-wider">{t.formBusinessType}</label>
                <select
                  value={distType}
                  onChange={(e) => setDistType(e.target.value)}
                  className="p-3.5 rounded-xl border border-primary-brand/10 focus:border-secondary-brand bg-accent-brand/45 text-sm outline-none cursor-pointer"
                >
                  <option value="Supermarket">Supermarket / Grocery chain</option>
                  <option value="Event Planner">Event organizer / Marriage Hall owner</option>
                  <option value="Corporate Office">Distributor office supply</option>
                  <option value="Wholesaler">Regional wholesale distributor</option>
                </select>
              </div>
            </div>

            {isDistSubmitSuccessful ? (
              <div className="p-4 bg-green-500/10 border border-green-500/30 text-green-700 font-bold rounded-xl text-center text-xs sm:text-sm animate-pulse select-none">
                ✓ {t.subSuccessDesc}
              </div>
            ) : (
              <button
                type="submit"
                className="w-full bg-primary-brand hover:bg-primary-brand/90 hover:scale-102 transition-all text-white font-black py-4 rounded-xl shadow-lg cursor-pointer text-center"
              >
                {t.distributorBtn}
              </button>
            )}

          </form>

        </div>
      </section>


      {/* 7.5 LOCATION MAP (ILLUSTATED EMBED) */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-primary-brand/5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-4 space-y-4 text-left flex flex-col items-start justify-center">
            <h2 className="text-3xl font-black font-serif text-primary-brand leading-none">
              {language === 'en' ? "Our Sourcing Base Hub" : "منرل بوٹلنگ ہیڈ کوارٹر"}
            </h2>
            <p className="text-xs sm:text-sm text-text-primary/70 leading-relaxed">
              {language === 'en' ? "Aabshar mineral water primary logistical bottling and dispatch centers are located in central Pakistan, utilizing advanced clinical purification to guarantee the freshest, cleanest premium hydration." : "ہمارے کسٹمر ڈیلیوری ہب ہر شہر کے قلب میں واقع ہیں تاکہ کارٹن بروقت اور بغیر کسی تپش کے آپ کے دروازے تک فری ٹرانسپورٹ کیے جائیں۔"}
            </p>
            <div className="flex gap-2.5 items-center mt-2.5">
              <MapPin className="h-5 w-5 text-secondary-brand shrink-0" />
              <p className="text-xs font-bold text-primary-brand">Main Depot, Gulberg Industrial Area, Lahore, Pakistan</p>
            </div>
          </div>

          {/* Map Vector box */}
          <div className="lg:col-span-8 h-80 w-full bg-slate-100 rounded-2xl border border-slate-200 shadow-inner relative overflow-hidden flex items-center justify-center select-none">
            
            {/* Animated satellite simulation pins */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
              <span className="relative flex h-5 w-5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-brand opacity-75" />
                <span className="relative inline-flex rounded-full h-5 w-5 bg-primary-brand" />
              </span>
              <span className="bg-dark-base text-white text-[10px] font-black mt-2.5 p-2 rounded shadow-lg border border-white/5">
                Aabshar Lahore Logistics HQ 🚚
              </span>
            </div>

            <div className="absolute bottom-4 left-4 text-[9px] text-slate-500 font-bold uppercase tracking-widest">
              Aabshar Bottling Hubs
            </div>

          </div>

        </div>
      </section>

    </div>
  );
};
