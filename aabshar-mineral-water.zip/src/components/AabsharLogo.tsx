/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface AabsharLogoProps {
  className?: string;
  showText?: boolean;
}

export const AabsharLogo: React.FC<AabsharLogoProps> = ({ className = 'h-12 w-auto', showText = true }) => {
  return (
    <div className={`flex items-center justify-center select-none ${className}`}>
      <img
        src="/src/assets/images/aabshar_logo_official_1779701263465.png"
        alt="Aabshar Premium Mineral Water Logo"
        className="h-full w-auto object-contain select-none pointer-events-none"
        referrerPolicy="no-referrer"
      />
      {showText && (
        <span className="sr-only">Aabshar</span>
      )}
    </div>
  );
};
