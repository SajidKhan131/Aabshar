/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { Smartphone, CheckCircle, Truck, MapPin, Calendar, Compass, ShieldAlert, PhoneCall, HelpCircle } from 'lucide-react';

interface DeliveryViewProps {
  language: Language;
}

export const DeliveryView: React.FC<DeliveryViewProps> = ({ language }) => {
  const t = translations[language];

  const activeCities = [
    { nameEn: "Rawalpindi", nameUr: "راولپنڈی", coord: "top-[29%] left-[58%]" },
    { nameEn: "Islamabad", nameUr: "اسلام آباد", coord: "top-[25%] left-[60%]" },
    { nameEn: "Fateh Jang", nameUr: "فتح جنگ", coord: "top-[32%] left-[45%]" },
  ];

  const upcomingCities = [
    { nameEn: "Peshawar", nameUr: "پشاور", coord: "top-[24%] left-[30%]" },
    { nameEn: "Faisalabad", nameUr: "فیصل آباد", coord: "top-[48%] left-[52%]" },
    { nameEn: "Hazara", nameUr: "ہزارہ", coord: "top-[18%] left-[65%]" },
  ];

  return (
    <div className={`pt-20 bg-accent-brand ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}>
      
      {/* 3.1 HERO BANNER - BRIGHT CRYSTAL THEME */}
      <section className="relative py-20 bg-gradient-to-b from-[#E7F3FC] via-[#F6FBFF] to-accent-brand text-text-primary overflow-hidden text-center select-none border-b border-primary-brand/10">
        
        {/* Soft glowing vector layout */}
        <div className="absolute top-0 right-0 w-80 h-80 rounded-full border border-primary-brand/10 animate-ripple pointer-events-none" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-secondary-brand/10 rounded-full filter blur-[60px] pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <h1 className="text-3xl sm:text-5xl font-black font-serif text-primary-brand drop-shadow-sm">
            {t.deliveryHeroHeading}
          </h1>
          <p className="text-text-primary/75 max-w-2xl mx-auto text-sm sm:text-base leading-relaxed font-medium">
            {t.deliveryHeroSub}
          </p>
        </div>
      </section>


      {/* 3.2 HOW IT WORKS (3-Step Process) */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-16">
        
        <div className="space-y-3 max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-primary-brand font-serif">
            {language === 'en' ? "How Simple It Is to Hydrate" : "آرڈر اور ڈیلیوری کا آسان ترین طریقہ"}
          </h2>
          <p className="text-text-primary/70 text-sm">
            {language === 'en' ? "Get premium mineral water carton delivered inside your home storage in just three simple steps." : "انتہائی لذیذ اور خالص گلیشیئر واٹر منگوانا اب چند کلکس پر ممکن ہے"}
          </p>
        </div>

        {/* 3-step timeline */}
        <div className="relative max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
          
          {/* Connector line (Desktop) */}
          <div className="hidden md:block absolute top-12 left-[15%] right-[15%] h-0.5 bg-secondary-brand/25 z-0" />

          {/* Step 1 */}
          <div className="bg-white p-6 rounded-2xl border border-primary-brand/5 shadow-md flex flex-col items-center text-center gap-4 relative z-10 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-primary-brand text-2xl font-black">
              📱
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.step1Title}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed max-w-xs">{t.step1Desc}</p>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-6 rounded-2xl border border-primary-brand/5 shadow-md flex flex-col items-center text-center gap-4 relative z-10 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-600 text-2xl font-black">
              ✅
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.step2Title}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed max-w-xs">{t.step2Desc}</p>
          </div>

          {[
            // Step 3
          ]}
          <div className="bg-white p-6 rounded-2xl border border-primary-brand/5 shadow-md flex flex-col items-center text-center gap-4 relative z-10 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center text-green-600 text-2xl font-black">
              🚚
            </div>
            <h3 className="font-black text-base text-primary-brand">{t.step3Title}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed max-w-xs">{t.step3Desc}</p>
          </div>

        </div>

      </section>


      {/* 3.3 DELIVERY COVERAGE */}
      <section className="py-24 bg-white border-t border-primary-brand/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column (Text & Cities grid) (5 items) */}
            <div className="lg:col-span-6 space-y-6 text-left flex flex-col items-start justify-center">
              <h2 className="text-3xl font-black font-serif text-primary-brand">
                {t.deliveryCoverageTitle}
              </h2>
              <p className="text-text-primary/70 text-sm leading-relaxed">
                {t.deliveryCoverageSub}
              </p>

              {/* Cities list Grid display */}
              <div className="w-full space-y-4 pt-4">
                {/* Active Hubs */}
                <div className="space-y-2">
                  <span className="text-xs font-black uppercase tracking-wider text-green-600 flex items-center gap-1.5">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    {language === 'en' ? "Currently Active Delivery Cities" : "فعال کسٹمر ہوم ڈیلیوری زونز"}
                  </span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full">
                    {activeCities.map((city, idx) => (
                      <div key={idx} className="flex items-center gap-2.5 bg-green-500/5 p-3.5 rounded-xl border border-green-500/15 hover:border-green-500/35 transition-all select-none">
                        <MapPin className="h-5 w-5 text-green-600 shrink-0" />
                        <div>
                          <p className="font-bold text-sm text-primary-brand">{city.nameEn}</p>
                          <p className="text-[10px] text-text-primary/50 tracking-wide font-urdu">{city.nameUr}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Upcoming / Expanding Cities */}
                <div className="space-y-2 pt-2">
                  <span className="text-xs font-black uppercase tracking-wider text-text-primary/50 flex items-center gap-1.5">
                    <span>🚀</span>
                    {language === 'en' ? "Upcoming Expansion Areas (Coming Soon)" : "توسیعی مرحلہ (عنقریب سپلائی)"}
                  </span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full">
                    {upcomingCities.map((city, idx) => (
                      <div key={idx} className="flex items-center gap-2.5 bg-gray-50 p-3.5 rounded-xl border border-primary-brand/5 hover:border-secondary-brand/15 opacity-80 hover:opacity-100 transition-all select-none relative overflow-hidden group">
                        <div className="absolute top-1.5 right-1.5 text-[8px] font-black bg-primary-brand/10 text-primary-brand rounded px-1.5 py-0.5 transform scale-90 sm:scale-100 uppercase tracking-wider">
                          {language === 'en' ? "Soon" : "عنقریب"}
                        </div>
                        <MapPin className="h-5 w-5 text-text-primary/40 shrink-0" />
                        <div>
                          <p className="font-bold text-sm text-text-primary/80">{city.nameEn}</p>
                          <p className="text-[10px] text-text-primary/40 tracking-wide font-urdu">{city.nameUr}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Disclaimer */}
              <div className="flex gap-2 bg-yellow-400/10 border border-yellow-400/30 p-4 rounded-xl text-xs text-text-primary/80 mt-4">
                <Compass className="h-5 w-5 text-orange-600 shrink-0" />
                <p>{t.notOnMapNote}</p>
              </div>
            </div>

            {/* Right Column (Pakistan map vector/pins) */}
            <div className="lg:col-span-6 flex justify-center select-none relative bg-accent-brand/40 border border-primary-brand/5 rounded-3xl p-6 sm:p-10 h-[500px]">
              
              {/* Abstract Map Box representing Pakistan territory outline */}
              <svg className="absolute inset-0 w-full h-full text-primary-brand/5" fill="none" viewBox="0 0 400 500">
                <path d="M150 50 C180 30, 220 20, 260 40 C300 60, 320 100, 310 140 C300 180, 260 220, 280 260 C300 300, 340 320, 330 360 C320 400, 280 440, 240 450 C200 460, 160 430, 140 390 C120 350, 100 340, 80 310 C60 280, 50 240, 70 200 C90 160, 110 140, 120 100 C130 60, 140 70, 150 50 Z" fill="currentColor" />
              </svg>

              <div className="relative w-full h-full">
                {/* Visual compass logo */}
                <div className="absolute top-4 right-4 text-primary-brand/20 text-xs font-black">N 🧭 S</div>

                {/* Plot active glowing pins representing active regional hubs */}
                {activeCities.map((city, idx) => (
                  <div
                    key={`active-pin-${idx}`}
                    className={`absolute ${city.coord} flex items-center gap-1.5 animate-float-medium`}
                    style={{ animationDelay: `${idx * 0.4}s` }}
                  >
                    <span className="relative flex h-3 w-3 select-none">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                    </span>
                    <span className="bg-[#122b3d] text-white rounded text-[10px] font-black px-1.5 py-0.5 shadow-md">
                      {language === 'en' ? city.nameEn : city.nameUr}
                    </span>
                  </div>
                ))}

                {/* Plot upcoming expansion pins */}
                {upcomingCities.map((city, idx) => (
                  <div
                    key={`upcoming-pin-${idx}`}
                    className={`absolute ${city.coord} flex items-center gap-1.2 opacity-75 hover:opacity-100 transition-opacity`}
                  >
                    <span className="relative flex h-2 w-2 select-none">
                      <span className="animate-pulse absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                    <span className="bg-white text-primary-brand border border-primary-brand/10 rounded text-[9px] font-bold px-1.5 py-0.5 shadow">
                      {language === 'en' ? `${city.nameEn} (Soon)` : `${city.nameUr} (عنقریب)`}
                    </span>
                  </div>
                ))}
              </div>

            </div>

          </div>
        </div>
      </section>


      {/* 3.4 DELIVERY PROMISE CARDS */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <h2 className="text-3xl font-black font-serif text-primary-brand text-center">
          {language === 'en' ? "Our Delivery Guarantees" : "آبشار ڈیلیوری کا محفوظ اور پکا وعدہ"}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm text-left col-span-1 space-y-4">
            <span className="text-4xl">⚡</span>
            <h3 className="font-black text-lg text-primary-brand">{t.dayDeliveryTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.dayDeliveryDesc}</p>
          </div>

          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm text-left col-span-1 space-y-4">
            <span className="text-4xl">🧊</span>
            <h3 className="font-black text-lg text-primary-brand">{t.tempTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.tempDesc}</p>
          </div>

          <div className="glass-panel p-8 rounded-2xl border border-white/40 shadow-sm text-left col-span-1 space-y-4">
            <span className="text-4xl">📦</span>
            <h3 className="font-black text-lg text-primary-brand">{t.secureBoxTitle}</h3>
            <p className="text-xs text-text-primary/70 leading-relaxed">{t.secureBoxDesc}</p>
          </div>

        </div>
      </section>


      {/* 3.5 ORDER CTA BANNER - BRIGHT CRYSTAL THEME */}
      <section className="py-20 bg-gradient-to-b from-white to-[#EAF6FC] text-text-primary text-center select-none relative z-10 overflow-hidden border-t border-primary-brand/10">
        
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-secondary-brand/10 filter blur-[100px] -z-10 pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 flex flex-col items-center">
          <div className="space-y-3">
            <h2 className="text-3xl sm:text-4xl font-black font-serif text-dark-base">
              {t.readyOrderTitle}
            </h2>
            <p className="text-text-primary/75 text-sm max-w-lg mx-auto leading-relaxed">
              {language === 'en' ? "Submit request to our digital coordinator - we deliver instantly." : "آرڈر فارم کا کسٹمر ڈیسک واٹس ایپ چوبیس گھنٹے فعال ہے۔"}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 w-full justify-center max-w-md">
            <a
              href={`https://wa.me/923004752668?text=${encodeURIComponent(
                language === 'en'
                  ? "Hello! I am ready to order mineral water cartons. Please book my slot."
                  : "سلام علیکم! مجھے منرل واٹر پانی کا ہوم آرڈر درج کروانا ہے۔"
              )}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 font-black text-white px-8 py-4 rounded-xl shadow-lg transition-all"
            >
              <span>{t.whatsappOrder}</span>
            </a>

            <a
              href="tel:+923051999897"
              className="flex items-center justify-center gap-2 bg-white hover:bg-primary-brand/5 text-primary-brand font-bold border border-primary-brand/20 px-8 py-4 rounded-xl transition-all shadow-sm"
            >
              <PhoneCall className="h-4.5 w-4.5 text-primary-brand" />
              <span>{t.callUsDirect} +92 305 1999897</span>
            </a>
          </div>
        </div>
      </section>

    </div>
  );
};
