/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, X, MessageCircle, Globe } from 'lucide-react';
import { Language, ActivePage } from '../types';
import { AabsharLogo } from './AabsharLogo';
import { translations } from '../utils/translations';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  setLanguage,
  activePage,
  setActivePage,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const t = translations[language];

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: ActivePage; labelKey: string }[] = [
    { id: 'home', labelKey: 'navHome' },
    { id: 'products', labelKey: 'navProducts' },
    { id: 'quality', labelKey: 'navQuality' },
    { id: 'b2b', labelKey: 'navB2b' },
    { id: 'delivery', labelKey: 'navAbout' }, // Wait, the plan lists delivery, B2B, Quality, about, contact. Let's make sure we map them correctly
  ];

  const fullNavItems: { id: ActivePage; label: string }[] = [
    { id: 'home', label: t.navHome },
    { id: 'products', label: t.navProducts },
    { id: 'quality', label: t.navQuality },
    { id: 'b2b', label: t.navB2b },
    { id: 'delivery', label: t.navProducts }, // Let's list all 7 active pages
    { id: 'about', label: t.navAbout },
    { id: 'contact', label: t.navContact },
  ];

  // Unique elements for the header
  const menuLinks: { id: ActivePage; label: string }[] = [
    { id: 'home', label: t.navHome },
    { id: 'products', label: t.navProducts },
    { id: 'quality', label: t.navQuality },
    { id: 'b2b', label: t.navB2b },
    { id: 'about', label: t.navAbout },
    { id: 'contact', label: t.navContact },
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ur' : 'en');
  };

  const handleNavClick = (pageId: ActivePage) => {
    setActivePage(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/85 backdrop-blur-md shadow-md py-3 border-b border-primary-brand/10'
          : 'bg-white/55 backdrop-blur-sm py-4 border-b border-primary-brand/5'
      } ${language === 'ur' ? 'rtl font-urdu' : 'font-sans'}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          
          {/* Brand Logo Left */}
          <div
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <AabsharLogo className="h-10 hover:scale-105 transition-transform" />
          </div>

          {/* Desktop Navigation Center */}
          <nav className="hidden md:flex gap-6 lg:gap-8 items-center bg-white/30 px-5 py-2 rounded-full border border-primary-brand/10 backdrop-blur-md shadow-sm">
            {menuLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`relative py-1 text-sm font-semibold transition-all duration-200 outline-none hover:text-primary-brand ${
                  activePage === item.id
                    ? 'text-primary-brand font-black'
                    : 'text-text-primary/80 hover:text-primary-brand'
                }`}
              >
                {item.label}
                {activePage === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-secondary-brand rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Right Action buttons */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all ${
                isScrolled
                  ? 'border-primary-brand/20 text-text-primary bg-white/50 hover:bg-primary-brand/5'
                  : 'border-primary-brand/15 text-text-primary bg-white/35 hover:bg-primary-brand/5'
              }`}
            >
              <Globe className="h-3.5 w-3.5" />
              <span>{t.langToggle}</span>
            </button>

            {/* WhatsApp Quick Order button */}
            <a
              href={`https://wa.me/923004752668?text=${encodeURIComponent(
                language === 'en'
                  ? "Hello Aabshar! I would like to order mineral water cartons. Please share details."
                  : "اسلام علیکم آبشار! مجھے منرل واٹر کے ڈبے آرڈر کرنے ہیں۔ براہ کرم تفصیلات شئیر کریں۔"
              )}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold text-sm px-4 py-2.5 rounded-full shadow-md hover:shadow-green-900/40 transition-all select-none"
            >
              <MessageCircle className="h-4.5 w-4.5 fill-white text-green-600" />
              <span>{t.whatsappOrder}</span>
            </a>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex items-center md:hidden gap-2">
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-xs font-semibold transition-all ${
                isScrolled
                  ? 'border-primary-brand/20 text-text-primary bg-white/40'
                  : 'border-primary-brand/15 text-text-primary bg-white/30'
              }`}
            >
              <Globe className="h-3 w-3" />
              <span className="text-[10px]">{t.langToggle}</span>
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-full transition-colors text-text-primary hover:bg-primary-brand/5"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed top-20 left-4 right-4 z-40 bg-white/95 border border-primary-brand/15 rounded-2xl p-6 shadow-2xl backdrop-blur-xl animate-float-medium">
          <nav className="flex flex-col gap-4">
            {menuLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`py-2 text-left text-base font-semibold border-b border-primary-brand/5 pb-2 transition-colors ${
                  activePage === item.id
                    ? 'text-primary-brand font-black pl-2'
                    : 'text-text-primary/75 hover:text-primary-brand'
                }`}
              >
                {language === 'ur' ? (
                  <span className="flex justify-between items-center">
                    <span>{item.label}</span>
                    <span className="text-xs text-text-primary/20">←</span>
                  </span>
                ) : (
                  <span className="flex justify-between items-center">
                    <span>{item.label}</span>
                    <span className="text-xs text-text-primary/20">→</span>
                  </span>
                )}
              </button>
            ))}

            {/* Mobile WhatsApp Button */}
            <a
              href={`https://wa.me/923004752668?text=${encodeURIComponent(
                language === 'en'
                  ? "Hello Aabshar! I would like to order mineral water cartons. Please share details."
                  : "اسلام علیکم آبشار! مجھے منرل واٹر کے ڈبے آرڈر کرنے ہیں۔ براہ کرم تفصیلات شئیر کریں۔"
              )}`}
              target="_blank"
              rel="noreferrer"
              className="mt-2 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold py-3.5 rounded-xl text-center shadow-lg transition-all"
            >
              <MessageCircle className="h-5 w-5 fill-white text-green-600" />
              <span>{t.whatsappOrder}</span>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};
