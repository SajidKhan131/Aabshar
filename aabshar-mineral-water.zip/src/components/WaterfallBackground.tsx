/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';

export const WaterfallBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;

    // Load background image
    const bgImage = new Image();
    bgImage.src = 'https://images.unsplash.com/photo-1527489377706-5bf97e608852?auto=format&fit=crop&q=80&w=1920';
    let imageLoaded = false;
    bgImage.onload = () => {
      imageLoaded = true;
    };

    // Particles simulation states
    interface StreamParticle {
      x: number;
      y: number;
      vy: number;
      length: number;
      width: number;
      opacity: number;
    }

    interface MistParticle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      opacity: number;
      life: number;
      maxLife: number;
    }

    const streams: StreamParticle[] = [];
    const mists: MistParticle[] = [];
    const maxStreams = 65;
    const maxMists = 40;

    const initParticles = (w: number, h: number) => {
      streams.length = 0;
      mists.length = 0;

      // Initialize streams across the right 50% section where waterfall visuals are displayed
      for (let i = 0; i < maxStreams; i++) {
        streams.push({
          x: w * (0.45 + Math.random() * 0.55),
          y: Math.random() * h,
          vy: 3 + Math.random() * 5,
          length: 15 + Math.random() * 25,
          width: 1 + Math.random() * 1.5,
          opacity: 0.1 + Math.random() * 0.35,
        });
      }

      // Initialize mists
      for (let i = 0; i < maxMists; i++) {
        mists.push(createMist(w, h, true));
      }
    };

    const createMist = (w: number, h: number, initAnywhere = false): MistParticle => {
      return {
        // Concentrate mist on the right side and bottom half where waterfall pool is
        x: w * (0.5 + Math.random() * 0.5),
        y: initAnywhere ? h * (0.4 + Math.random() * 0.6) : h * (0.85 + Math.random() * 0.15),
        vx: -0.2 + Math.random() * 0.4,
        vy: -0.3 - Math.random() * 0.5,
        radius: 30 + Math.random() * 55,
        opacity: 0.02 + Math.random() * 0.08,
        life: initAnywhere ? Math.random() * 100 : 0,
        maxLife: 150 + Math.random() * 150,
      };
    };

    // Clean canvas resize handler with Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: entryWidth, height: entryHeight } = entry.contentRect;
        width = Math.ceil(entryWidth);
        height = Math.ceil(entryHeight);
        canvas.width = width;
        canvas.height = height;
        initParticles(width, height);
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    let sunbeamAngle = 0;

    // Simulation loop
    const animate = () => {
      if (width === 0 || height === 0) {
        animationFrameId = requestAnimationFrame(animate);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      // 1. Draw Background Waterfall image
      if (imageLoaded) {
        // Slow Ken Burns cinematic scaling & subtle shift over infinite loop
        const scale = 1.05;
        const offset = 5;
        ctx.drawImage(bgImage, -offset, -offset, width * scale + offset * 2, height * scale + offset * 2);
      } else {
        // Fallback smooth background gradient matching the site style
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#E7F3FC');
        grad.addColorStop(1, '#F4FAFE');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      }

      // 2. Clear Left Overlay gradient sheet (Ensures typography and CTA reading remains perfectly crisp)
      // Fade from ice-blue-white on left 40% of page to transparent on right, giving a natural high-contrast container backing
      const lightOverlay = ctx.createLinearGradient(0, 0, width, 0);
      lightOverlay.addColorStop(0, 'rgba(231, 243, 252, 0.98)');
      lightOverlay.addColorStop(0.35, 'rgba(231, 243, 252, 0.92)');
      lightOverlay.addColorStop(0.55, 'rgba(244, 250, 254, 0.75)');
      lightOverlay.addColorStop(0.8, 'rgba(244, 250, 254, 0.15)');
      lightOverlay.addColorStop(1, 'rgba(244, 250, 254, 0.02)');
      ctx.fillStyle = lightOverlay;
      ctx.fillRect(0, 0, width, height);

      // 3. Draw Water Streams (Cinematic Cascading Droplets on right 50%)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.lineCap = 'round';
      for (const p of streams) {
        ctx.beginPath();
        ctx.lineWidth = p.width;
        ctx.strokeStyle = `rgba(224, 247, 255, ${p.opacity})`;
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x, p.y + p.length);
        ctx.stroke();

        // Update particle
        p.y += p.vy;
        // Reset when falling past screen
        if (p.y > height) {
          p.y = -p.length;
          p.x = width * (0.45 + Math.random() * 0.55);
          p.vy = 3 + Math.random() * 5;
          p.opacity = 0.1 + Math.random() * 0.35;
        }
      }

      // 4. Draw Rising Misty Vapor Pools
      for (let i = 0; i < mists.length; i++) {
        const m = mists[i];
        
        // Render misty radial glow
        const radGrad = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, m.radius);
        const currentOpacity = m.opacity * Math.sin((m.life / m.maxLife) * Math.PI);
        radGrad.addColorStop(0, `rgba(240, 251, 255, ${currentOpacity})`);
        radGrad.addColorStop(0.6, `rgba(240, 251, 255, ${currentOpacity * 0.4})`);
        radGrad.addColorStop(1, 'rgba(240, 251, 255, 0)');

        ctx.fillStyle = radGrad;
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
        ctx.fill();

        // Update mist
        m.x += m.vx;
        m.y += m.vy;
        m.life++;

        // Reset dead particle
        if (m.life >= m.maxLife || m.y < height * 0.2) {
          mists[i] = createMist(width, height, false);
        }
      }

      // 5. Draw Panoramic Sunbeams from Top Right
      sunbeamAngle += 0.0012;
      ctx.save();
      ctx.translate(width * 0.9, height * 0.15);
      ctx.rotate(sunbeamAngle);

      const numBeams = 4;
      for (let j = 0; j < numBeams; j++) {
        const angleOffset = (j * Math.PI * 2) / numBeams;
        
        ctx.beginPath();
        ctx.moveTo(0, 0);
        // Sector beam shape
        ctx.arc(0, 0, Math.max(width, height) * 0.8, angleOffset - 0.15, angleOffset + 0.15);
        ctx.closePath();

        const beamGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, Math.max(width, height) * 0.8);
        beamGrad.addColorStop(0, 'rgba(255, 255, 255, 0.12)');
        beamGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.04)');
        beamGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

        ctx.fillStyle = beamGrad;
        ctx.fill();
      }
      ctx.restore();

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 w-full h-full overflow-hidden select-none pointer-events-none z-0"
    >
      <canvas 
        ref={canvasRef} 
        className="block w-full h-full mix-blend-normal"
      />
    </div>
  );
};
