/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'en' | 'ur';

export type ActivePage = 'home' | 'products' | 'delivery' | 'b2b' | 'quality' | 'about' | 'contact';

export interface Product {
  id: string;
  nameEn: string;
  nameUr: string;
  taglineEn: string;
  taglineUr: string;
  descEn: string;
  descUr: string;
  image: string;
  volume: string;
  tds: string;
  sourceEn: string;
  sourceUr: string;
  capEn: string;
  capUr: string;
  packagingEn: string;
  packagingUr: string;
  packs: {
    nameEn: string;
    nameUr: string;
    price: number;
    count: number;
    savingsEn: string;
    savingsUr: string;
  }[];
}

export interface Testimonial {
  name: string;
  cityEn: string;
  cityUr: string;
  rating: number;
  commentEn: string;
  commentUr: string;
  initials: string;
}

export interface TimelineMilestone {
  year: string;
  titleEn: string;
  titleUr: string;
  descEn: string;
  descUr: string;
}

export interface B2BClientType {
  icon: string;
  titleEn: string;
  titleUr: string;
  descEn: string;
  descUr: string;
}

export interface MineralInfo {
  nameEn: string;
  nameUr: string;
  formula: string;
  range: string;
  benefitEn: string;
  benefitUr: string;
}
